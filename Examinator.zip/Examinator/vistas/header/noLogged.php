<div id="menuOptions">
        <ul>
            <li><a href="https://www.google.es">Sobre Nosotros</a></li>
            <li><a href="https://www.google.es">¿Que hacemos?</a></li>
            <li><a href="https://www.google.es">Contactar</a></li>
        </ul>
</div>
<div id="user-container">
        <a href="?menu=login">Inicia Sesión</a>
        <a> o </a>
        <a href="?menu=registro">Registrate</a>
</div>