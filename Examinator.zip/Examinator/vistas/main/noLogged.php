<article class="container">
        <div class="title">
            <h3>Sobre Nosotros</h3>
        </div>
        <div class="content">
            <div class="img">
                <img src="css/img/sobreNosotros.jpg" alt="" width="70%">
            </div>
            <div class="text">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus iaculis eleifend. Etiam auctor eros non enim dignissim, ut fermentum arcu rutrum. Mauris nunc lorem, semper sit amet suscipit vitae, semper varius turpis. Aliquam non ultricies ligula. Vivamus sit amet rhoncus orci. Integer non molestie justo, sit amet euismod est. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum commodo est ac nulla tristique, nec pulvinar est ornare. Vestibulum sit amet imperdiet nulla. Aliquam elit diam, varius quis arcu at, feugiat tincidunt nibh. Aliquam nec pulvinar leo. Integer ultricies, purus nec rhoncus mattis, magna arcu condimentum sapien, vitae maximus tellus sapien nec ipsum.</p>
                <br>
                <p>Aenean quis ornare lorem, ut volutpat quam. Fusce ultrices, lorem et facilisis suscipit, diam elit euismod elit, at commodo magna nulla eu sapien. Fusce sagittis odio eu metus porttitor, id euismod nisi semper. Nunc sed risus sodales, ullamcorper tellus id, luctus metus. Proin at porta risus. Nulla id diam congue, mollis ex a, ultricies risus. Quisque eu mi tincidunt, varius urna vitae, porta nulla.</p>
                <br>
                <p>Integer turpis eros, finibus nec posuere vel, tincidunt et nulla. Phasellus vel vehicula lacus. Curabitur sollicitudin orci metus, quis condimentum erat rhoncus et. Morbi gravida nisi et leo suscipit dapibus. Donec finibus arcu non tellus tincidunt convallis. Fusce tellus nisl, rutrum sit amet rutrum sit amet, condimentum nec tellus. Phasellus sagittis lacus id sem tempor, aliquet fermentum nisl cursus. Suspendisse ex ipsum, bibendum et quam nec, elementum blandit odio. Nulla suscipit arcu id purus commodo ornare. Curabitur at erat augue. Curabitur nec cursus tortor, quis sagittis arcu. Mauris sit amet tincidunt lorem. Vestibulum in orci a massa laoreet lobortis eu at tortor.</p>
            </div>
        </div>
    </article>
    <article class="container">
        <div class="title">
            <h3>¿Que hacemos?</h3>
        </div>
        <div class="content">
            <div class="img">
                <img src="css/img/sobreNosotros.jpg" alt="" width="70%">
            </div>
            <div class="text">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus iaculis eleifend. Etiam auctor eros non enim dignissim, ut fermentum arcu rutrum. Mauris nunc lorem, semper sit amet suscipit vitae, semper varius turpis. Aliquam non ultricies ligula. Vivamus sit amet rhoncus orci. Integer non molestie justo, sit amet euismod est. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum commodo est ac nulla tristique, nec pulvinar est ornare. Vestibulum sit amet imperdiet nulla. Aliquam elit diam, varius quis arcu at, feugiat tincidunt nibh. Aliquam nec pulvinar leo. Integer ultricies, purus nec rhoncus mattis, magna arcu condimentum sapien, vitae maximus tellus sapien nec ipsum.</p>
                <br>
                <p>Aenean quis ornare lorem, ut volutpat quam. Fusce ultrices, lorem et facilisis suscipit, diam elit euismod elit, at commodo magna nulla eu sapien. Fusce sagittis odio eu metus porttitor, id euismod nisi semper. Nunc sed risus sodales, ullamcorper tellus id, luctus metus. Proin at porta risus. Nulla id diam congue, mollis ex a, ultricies risus. Quisque eu mi tincidunt, varius urna vitae, porta nulla.</p>
                <br>
                <p>Integer turpis eros, finibus nec posuere vel, tincidunt et nulla. Phasellus vel vehicula lacus. Curabitur sollicitudin orci metus, quis condimentum erat rhoncus et. Morbi gravida nisi et leo suscipit dapibus. Donec finibus arcu non tellus tincidunt convallis. Fusce tellus nisl, rutrum sit amet rutrum sit amet, condimentum nec tellus. Phasellus sagittis lacus id sem tempor, aliquet fermentum nisl cursus. Suspendisse ex ipsum, bibendum et quam nec, elementum blandit odio. Nulla suscipit arcu id purus commodo ornare. Curabitur at erat augue. Curabitur nec cursus tortor, quis sagittis arcu. Mauris sit amet tincidunt lorem. Vestibulum in orci a massa laoreet lobortis eu at tortor.</p>
            </div>
        </div>
    </article>
    <article class="container">
        <div class="title">
            <h3>Contactanos</h3>
        </div>
        <div class="content">
            <div class="img">
                <img src="css/img/sobreNosotros.jpg" alt="" width="70%">
            </div>
            <div class="text">
                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Donec luctus iaculis eleifend. Etiam auctor eros non enim dignissim, ut fermentum arcu rutrum. Mauris nunc lorem, semper sit amet suscipit vitae, semper varius turpis. Aliquam non ultricies ligula. Vivamus sit amet rhoncus orci. Integer non molestie justo, sit amet euismod est. Interdum et malesuada fames ac ante ipsum primis in faucibus. Vestibulum commodo est ac nulla tristique, nec pulvinar est ornare. Vestibulum sit amet imperdiet nulla. Aliquam elit diam, varius quis arcu at, feugiat tincidunt nibh. Aliquam nec pulvinar leo. Integer ultricies, purus nec rhoncus mattis, magna arcu condimentum sapien, vitae maximus tellus sapien nec ipsum.</p>
                <br>
                <p>Aenean quis ornare lorem, ut volutpat quam. Fusce ultrices, lorem et facilisis suscipit, diam elit euismod elit, at commodo magna nulla eu sapien. Fusce sagittis odio eu metus porttitor, id euismod nisi semper. Nunc sed risus sodales, ullamcorper tellus id, luctus metus. Proin at porta risus. Nulla id diam congue, mollis ex a, ultricies risus. Quisque eu mi tincidunt, varius urna vitae, porta nulla.</p>
                <br>
                <p>Integer turpis eros, finibus nec posuere vel, tincidunt et nulla. Phasellus vel vehicula lacus. Curabitur sollicitudin orci metus, quis condimentum erat rhoncus et. Morbi gravida nisi et leo suscipit dapibus. Donec finibus arcu non tellus tincidunt convallis. Fusce tellus nisl, rutrum sit amet rutrum sit amet, condimentum nec tellus. Phasellus sagittis lacus id sem tempor, aliquet fermentum nisl cursus. Suspendisse ex ipsum, bibendum et quam nec, elementum blandit odio. Nulla suscipit arcu id purus commodo ornare. Curabitur at erat augue. Curabitur nec cursus tortor, quis sagittis arcu. Mauris sit amet tincidunt lorem. Vestibulum in orci a massa laoreet lobortis eu at tortor.</p>
            </div>
        </div>
</article>