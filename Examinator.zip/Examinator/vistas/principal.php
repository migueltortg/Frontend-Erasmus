<head>
    <meta charset="UTF-8">
    <title>Examinator</title>
    <link rel="stylesheet" href="css/principal.css">
    <link rel="stylesheet" href="css/header.css">
    <link rel="stylesheet" href="css/main.css">
    <link rel="stylesheet" href="css/examen.css">
</head>