<!DOCTYPE html>

<div class="pregunta">
    <span class="numero"></span>
    <h2><span class="categoria"></span></h2>
    <p class="descripcion"></p>
</div>