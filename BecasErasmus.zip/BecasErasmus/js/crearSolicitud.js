var parteCandidato;
var parteItems;

window.addEventListener("load",function(){
    parteCandidato=this.document.getElementById('parteCandidato');
    parteItems=this.document.getElementById('parteItems');

    var idConvocatoria=this.document.getElementById('inputID');
    idConvocatoria.setAttribute("readonly", "readonly");
    
    parteItems.style.display="none";
    autocargarDatos();

    this.document.getElementById('inputSubmit').addEventListener("click",function(event){
        event.preventDefault();

        var validado=true;

        for(var i=0;i<this.parentNode.parentNode.childNodes[1].childNodes.length;i++){
            if(this.parentNode.parentNode.childNodes[1].childNodes[i].nodeName=="INPUT"){
                if(this.parentNode.parentNode.childNodes[1].childNodes[i].value==""){
                    validado=false;
                    this.parentNode.parentNode.childNodes[1].childNodes[i].style.border="5px solid red";
                    anterior(event);
                }else{
                    this.parentNode.parentNode.childNodes[1].childNodes[i].style.border="";
                }
            }
        }

        if(validado){
            for(var i=3;i<this.parentNode.parentNode.childNodes[3].childNodes.length;i++){
                if(this.parentNode.parentNode.childNodes[3].childNodes[i].type=="file" && this.parentNode.parentNode.childNodes[3].childNodes[i].files.length === 0){
                    validado=false;
                    this.parentNode.parentNode.childNodes[3].childNodes[i].style.border="5px solid red";
                }else if(this.parentNode.parentNode.childNodes[3].childNodes[i].type=="file"){
                    this.parentNode.parentNode.childNodes[3].childNodes[i].style.border="";
                }
            }
        }

        if(validado){
            var form=new FormData();
            var idConvocatoria=this.parentNode.parentNode.childNodes[1].childNodes[3].value;
            var grupo=this.parentNode.parentNode.childNodes[1].childNodes[23].value;
            var tfno=this.parentNode.parentNode.childNodes[1].childNodes[27].value;
            var email=this.parentNode.parentNode.childNodes[1].childNodes[31].value;
            var domicilio=this.parentNode.parentNode.childNodes[1].childNodes[35].value;
            var img=document.getElementById('blob').value;
            
            form.append("idConvocatoria",idConvocatoria);
            form.append("grupo",grupo);
            form.append("tfno",tfno);
            form.append("email",email);
            form.append("domicilio",domicilio);
            form.append("fotoPerfil",img);

            for(var i=3;i<this.parentNode.parentNode.childNodes[3].childNodes.length;i++){
                if(this.parentNode.parentNode.childNodes[3].childNodes[i].type=="file"){
                    var a=this.parentNode.parentNode.childNodes[3].childNodes[i].files[0];
                    form.append(this.parentNode.parentNode.childNodes[3].childNodes[i].id,a);
                }
            }
            fetch('api/crearSolicitud.php', {
                method: 'POST',
                body: form
            })
            .then(response => response.text())
            .then(data => {
                ruta= "http://localhost/BECASERASMUS/index.php?vista=inicio";
                window.location.href=ruta;
            });
        }else{
            console.log("HOLA");
        }
    });
});

function siguiente(ev){
    ev.preventDefault();

    parteItems.style.display="";
    parteCandidato.style.display="none";
}

function anterior(ev){
    ev.preventDefault();

    parteCandidato.style.display="";
    parteItems.style.display="none";
}

function autocargarDatos(){
    fetch('api/autocargarDatos.php')
    .then(response => response.json())
    .then(data => {
        
        var form=this.document.getElementById('formSolicitud');
        form.childNodes[1].childNodes[7].value=data.dni;
        form.childNodes[1].childNodes[7].setAttribute("readonly", "readonly");

        form.childNodes[1].childNodes[11].value=data.nombre;
        form.childNodes[1].childNodes[11].setAttribute("readonly", "readonly");

        form.childNodes[1].childNodes[15].value=data.ap1;
        form.childNodes[1].childNodes[15].setAttribute("readonly", "readonly");
        
        form.childNodes[1].childNodes[19].value=data.ap2;
        form.childNodes[1].childNodes[19].setAttribute("readonly", "readonly");
    });
}

function volver(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla+"&idConvocatoria="+document.getElementById('inputID').value;
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inicio');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}