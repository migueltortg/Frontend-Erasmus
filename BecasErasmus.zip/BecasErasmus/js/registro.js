var parteCandidato;
var parteTutor;
var submit;
window.addEventListener("load",function(){
    parteTutor=this.document.getElementById("parteTutor");
    parteCandidato=this.document.getElementById("parteCandidato");
    submit=this.document.getElementById("registroSubmit");
    var botonSiguiente=this.document.getElementById("buttonSiguiente");
    var botonAnterior=this.document.getElementById("buttonAnterior");
    parteTutor.style.display="none";
    anterior();
    submit.addEventListener("click",registrar);
    botonSiguiente.addEventListener("click",siguiente);
    botonAnterior.addEventListener("click",anterior);
});

function registrar(){
    var form=new FormData();
    
    var dni=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[3].childNodes[3].value;
    var contraseña=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[5].childNodes[3].value;
    var nombre=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[7].childNodes[3].value;
    var ap1=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[9].childNodes[3].value;
    var ap2=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[11].childNodes[3].value;
    var fecha_nac=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[13].childNodes[3].value;
    var grupo=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[15].childNodes[4].value;
    var tfno=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[17].childNodes[3].value;
    var email=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[19].childNodes[3].value;
    var domicilio=submit.parentNode.parentNode.parentNode.childNodes[1].childNodes[21].childNodes[3].value;

    var dniTutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[4].childNodes[3].value;
    var nombreTutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[6].childNodes[3].value;
    var ap1Tutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[8].childNodes[3].value;
    var ap2Tutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[10].childNodes[3].value;
    var tfnoTutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[12].childNodes[3].value;
    var emailTutor=submit.parentNode.parentNode.parentNode.childNodes[3].childNodes[14].childNodes[3].value;

    form.append("dni",dni);
    form.append("contraseña",contraseña);
    form.append("nombre",nombre);
    form.append("ap1",ap1);
    form.append("ap2",ap2);
    form.append("fecha_nac",fecha_nac);
    form.append("grupo",grupo);
    form.append("tfno",tfno);
    form.append("email",email);
    form.append("domicilio",domicilio);

    form.append("dniTutor",dniTutor);
    form.append("nombreTutor",nombreTutor);
    form.append("ap1Tutor",ap1Tutor);
    form.append("ap2Tutor",ap2Tutor);
    form.append("tfnoTutor",tfnoTutor);
    form.append("emailTutor",emailTutor);

    console.log(grupo);
    fetch('api/crearCandidato.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'login');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}

function anterior(){
    parteTutor.style.display="none";
    parteCandidato.style.display="";
}

function siguiente(){
    var fecha_nac=new Date(this.parentNode.parentNode.childNodes[1].childNodes[13].childNodes[3].value);
    var fecha_act=new Date();

    if(((fecha_act-fecha_nac)/(1000 * 60 * 60 * 24 * 365.25))>=18){//HACER QUE SI ES MAYOR DE EDAD SE ENVIE
        registrar();
    }else{
        alert("Al ser menor de edad debe dar los datos de un tutor");
        parteCandidato.style.display="none";
        parteTutor.style.display="";
    }
}