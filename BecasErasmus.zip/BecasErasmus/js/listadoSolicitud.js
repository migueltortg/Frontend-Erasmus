window.addEventListener("load",function(){
    this.document.getElementById('grupoFiltro').addEventListener("change",function(){
        cargarTabla(document.getElementById('grupoFiltro').value);
    });
    cargarTabla(this.document.getElementById('grupoFiltro').value);
});

function corregir(ev,boton){
    ev.preventDefault();
    ruta= "http://localhost/BECASERASMUS/index.php?vista=baremar&idSolicitud="+(boton.parentNode.parentNode.id);
    window.location.href=ruta;
}

function cargarTabla(valor){
    borrarTabla();
    form=new FormData();
    form.append("tipo",valor);
    fetch('api/crearTablaSolicitud.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.text())
    .then(data => {
        var solicitud=JSON.parse(data);

        for(var i=0;i<solicitud.length;i++){
            var tr = document.createElement("tr");
            tr.setAttribute("id",solicitud[i].id_solicitud);
            
            var id=document.createElement("td");
            id.innerHTML=solicitud[i].id_solicitud;
            tr.appendChild(id);

            var dni=document.createElement("td");
            dni.innerHTML=solicitud[i].dni_candidato;
            tr.appendChild(dni);

            var idConvocatoria=document.createElement("td");
            idConvocatoria.innerHTML=solicitud[i].id_convocatoria;
            tr.appendChild(idConvocatoria);

            var grupo=document.createElement("td");
            grupo.innerHTML=solicitud[i].grupo;
            tr.appendChild(grupo);

            var corregirContainer=document.createElement("td");

            var corregir=document.createElement("button");
            corregir.innerHTML="Corregir";
            
            corregir.setAttribute("onclick","corregir(event,this)")
            corregirContainer.appendChild(corregir);
            tr.appendChild(corregirContainer);

            document.getElementById('solicitudTabla').childNodes[3].appendChild(tr);
        }
    });
}

function borrarTabla(){
    if ( document.getElementById('solicitudTabla').childNodes[3].hasChildNodes() ){
        while ( document.getElementById('solicitudTabla').childNodes[3].childNodes.length >= 1 ){
            document.getElementById('solicitudTabla').childNodes[3].removeChild( document.getElementById('solicitudTabla').childNodes[3].firstChild );
        }
    }
}

function volver(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla;
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}