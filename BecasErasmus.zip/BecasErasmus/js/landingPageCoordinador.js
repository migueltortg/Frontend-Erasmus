function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}

function navegar(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla;
}