window.addEventListener("load",function(){
    this.document.getElementById('grupoFiltro').addEventListener("change",function(){
        cargarTabla(document.getElementById('grupoFiltro').value);
    });
    cargarTabla(this.document.getElementById('grupoFiltro').value);
});

function verMas(ev,boton){
    ev.preventDefault();
    ruta= "http://localhost/BECASERASMUS/index.php?vista=verConvocatoria&idConvocatoria="+(boton.parentNode.parentNode.id);
    window.location.href=ruta;
}

function cargarTabla(valor){
    borrarTabla();
    form=new FormData();
    form.append("tipo",valor);
    fetch('api/crearTablaConvocatoria.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.text())
    .then(data => {
        var convocatorias=JSON.parse(data);
        console.log(convocatorias);
        for(var i=0;i<convocatorias.length;i++){
            var tr = document.createElement("tr");
            tr.setAttribute("id",convocatorias[i].id_convocatoria);
            
            var id=document.createElement("td");
            id.innerHTML=convocatorias[i].id_convocatoria;
            tr.appendChild(id);

            var n_movilidades=document.createElement("td");
            n_movilidades.innerHTML=convocatorias[i].n_movilidades;
            tr.appendChild(n_movilidades);

            var tipo=document.createElement("td");
            tipo.innerHTML=convocatorias[i].tipo;
            tr.appendChild(tipo);

            var pais=document.createElement("td");
            pais.innerHTML=convocatorias[i].pais;
            tr.appendChild(pais);

            var verMasContainer=document.createElement("td");

            var btnVerMas=document.createElement("button");
            btnVerMas.innerHTML="Ver mas";
            
            btnVerMas.setAttribute("onclick","verMas(event,this)")
            verMasContainer.appendChild(btnVerMas);
            tr.appendChild(verMasContainer);

            document.getElementById('convocatoriaTabla').childNodes[3].appendChild(tr);
        }
    });
}

function borrarTabla(){
    if ( document.getElementById('convocatoriaTabla').childNodes[3].hasChildNodes() ){
        while ( document.getElementById('convocatoriaTabla').childNodes[3].childNodes.length >= 1 ){
            document.getElementById('convocatoriaTabla').childNodes[3].removeChild( document.getElementById('convocatoriaTabla').childNodes[3].firstChild );
        }
    }
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}