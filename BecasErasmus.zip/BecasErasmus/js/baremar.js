window.addEventListener("load",function(){
    this.document.getElementById('idSolicitud').style.display="none";
    try{
        this.document.getElementById('inputIdioma').parentNode.parentNode.childNodes[9].childNodes[1].addEventListener("change",function(){
            var form=new FormData();
            form.append("titulo",this.value);
            form.append("idConvocatoria",document.getElementById('inputIdConvocatoria').value);
            fetch('api/notaIdioma.php', {
                method: 'POST',
                body: form
            })
            .then(response => response.text())
            .then(data => {
                document.getElementById('inputIdioma').value=data;
            });
        });
    }catch{
        console.log("No idioma input");
    }

    this.document.getElementById('btnBaremar').addEventListener("click",function(event){
        event.preventDefault();
        var validado=true;
        for(var i=0;i<document.getElementById('tablaItems').childNodes[3].childNodes.length;i++){
            if(document.getElementById('tablaItems').childNodes[3].childNodes[i].nodeName=="TR"){
                console.log(document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[7].textContent);
                console.log(document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[11].childNodes[0].value);
                if(parseInt(document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[7].textContent)<document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[11].childNodes[0].value){
                    validado=false;
                    document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[11].childNodes[0].style.border="5px solid red";
                }else{
                    document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[11].childNodes[0].style.border="";
                }
            }
        }
        
        if(validado){
            var form=new FormData();

            form.append("idSolicitud",document.getElementById('idSolicitud').value);
            for(var i=0;i<document.getElementById('tablaItems').childNodes[3].childNodes.length;i++){
                if(document.getElementById('tablaItems').childNodes[3].childNodes[i].nodeType==1){
                    form.append("inputItem"+document.getElementById('tablaItems').childNodes[3].childNodes[i].id,document.getElementById('tablaItems').childNodes[3].childNodes[i].childNodes[11].childNodes[0].value);
                }
            }

            fetch('api/baremar.php', {
                method: 'POST',
                body: form
            })
            .then(response => response.text())
            .then(data => {
                volver("listadoSolicitud");
            });
        }else{
            console.log();
        }
        
    });
});

function volver(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla;
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}