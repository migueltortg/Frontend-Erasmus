var primeraParte;
var segundaParte;

window.addEventListener("load",function(){
    var tablaItem=this.document.getElementById('tablaItem');
    var tablaIdioma=this.document.getElementById('tablaIdiomas');
    tablaIdioma.style.display="none";
    for(var i=1;i<tablaItem.childNodes[3].childNodes.length;i=i+2){
        eliminarItem(tablaItem.childNodes[3].childNodes[i]);
        tablaItem.childNodes[3].childNodes[i].childNodes[1].firstChild.addEventListener("change",function(){
            if(this.checked){
                añadirItem(this.parentNode.parentNode);
            }else{
                eliminarItem(this.parentNode.parentNode);
            }
        });
    }
    primeraParte=this.document.getElementById('parteConvocatoria');
    segundaParte=this.document.getElementById('parteItems');
    segundaParte.style.display="none";
});

function añadirGrupo(ev){
    ev.preventDefault();

    var select =this.document.getElementById('selectGrupo');

    for(var i=0;i<select.childNodes.length;i++){
        if(select.childNodes[i].nodeType==1){
            if(select.value==select.childNodes[i].value){
                añadirTablaGrupo(select.childNodes[i].value);
                select.removeChild(select.childNodes[i]);
                select.removeChild(select.childNodes[i-1]);
            }
        }
    }
}

function añadirTablaGrupo(valor){
    var tabla = this.document.getElementById('tablaGruposAsig');
    var fila=document.createElement("tr");
    var celdaValor=document.createElement("td");
    var inputValor=document.createElement("input");
    inputValor.setAttribute("type","text");
    inputValor.setAttribute("name",valor);
    inputValor.setAttribute("readonly","readonly");
    inputValor.value=valor;
    
    var celdaEliminar=document.createElement("td");
    var inputEliminar=document.createElement("button");
    inputEliminar.setAttribute("onclick","eliminarTablaGrupo(event,this)");
    inputEliminar.innerHTML="-";
    celdaEliminar.appendChild(inputEliminar);

    celdaValor.appendChild(inputValor);
    fila.appendChild(celdaValor);
    celdaEliminar.appendChild(inputEliminar);
    fila.appendChild(celdaEliminar);
    tabla.appendChild(fila);
}

function eliminarTablaGrupo(ev,boton){
    ev.preventDefault();
    
    var select =this.document.getElementById('selectGrupo');
    var tabla = this.document.getElementById('tablaGruposAsig');
    var fila=boton.parentNode.parentNode;

    var option=document.createElement("option");
    option.setAttribute("value",fila.childNodes[0].childNodes[0].value);
    option.setAttribute("id",fila.childNodes[0].childNodes[0].value);
    option.innerHTML=fila.childNodes[0].childNodes[0].value;

    select.appendChild(option);
    tabla.removeChild(fila);
}


function siguiente(ev){
    ev.preventDefault();
    segundaParte.style.display="";
    primeraParte.style.display="none";
}

function retroceder(ev){
    ev.preventDefault();
    primeraParte.style.display="";
    segundaParte.style.display="none";
}

function añadirItem(boton){
    if(boton==boton.parentNode.parentNode.childNodes[3].childNodes[1]){
        var tablaIdioma=this.document.getElementById('tablaIdiomas');
        tablaIdioma.style.display="";
    }
    for(var i=0;i<boton.childNodes.length;i++){
        if(boton.childNodes[i].nodeName=="TD"){
            if(boton.childNodes[i].childNodes[1] instanceof HTMLSelectElement){
                boton.childNodes[i].childNodes[1].disabled=false;
            }
            if(boton.childNodes[i].firstChild.nodeName=="INPUT" && i!=1){
                boton.childNodes[i].firstChild.disabled=false;
            }
        }
    }
}

function eliminarItem(boton){
    if(boton==boton.parentNode.parentNode.childNodes[3].childNodes[1]){
        var tablaIdioma=this.document.getElementById('tablaIdiomas');
        tablaIdioma.style.display="none";
        for(var j=0;j<tablaIdioma.childNodes[3].childNodes[1].childNodes.length;j++){
            if(tablaIdioma.childNodes[3].childNodes[1].childNodes[j].nodeName=="TD"){
                tablaIdioma.childNodes[3].childNodes[1].childNodes[j].childNodes[1].value=null;
            }
        }
    }
    for(var i=0;i<boton.childNodes.length;i++){
        if(boton.childNodes[i].nodeName=="TD"){
            if(boton.childNodes[i].childNodes[1] instanceof HTMLSelectElement){
                boton.childNodes[i].childNodes[1].disabled=true;
            }
            if(boton.childNodes[i].firstChild.nodeName=="INPUT" && i!=1){
                boton.childNodes[i].firstChild.disabled=true;
            }
        }
    }
}

function volver(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla;
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}