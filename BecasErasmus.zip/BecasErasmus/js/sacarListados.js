window.addEventListener("load",function(){
    this.document.getElementById('grupoFiltro').addEventListener("change",function(){
        cargarTabla(document.getElementById('grupoFiltro').value);
    });
    cargarTabla(this.document.getElementById('grupoFiltro').value);
});

function enviarLista(ev,boton){
    ev.preventDefault();
    
    form=new FormData();
    form.append("id",boton.parentNode.parentNode.id);
    
    fetch('api/correoListado.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.text())
    .then(data => {
        console.log(data);
    });
}

function cargarTabla(valor){
    borrarTabla();
    form=new FormData();
    form.append("tipo",valor);
    fetch('api/crearTablaConvocatoria.php', {
        method: 'POST',
        body: form
    })
    .then(response => response.text())
    .then(data => {
        var convocatorias=JSON.parse(data);
        console.log(convocatorias);
        for(var i=0;i<convocatorias.length;i++){
            //SOLO SE AÑADEN LOS QUE ESTEN EN PLAZO DE ENVIAR LISTAS
            var fecha_inicio_listas=new Date(convocatorias[i].f_inicio_listas_definitivas);
            var fecha_fin_listas=new Date(convocatorias[i].f_fin_listas_definitivas);
            var fecha_actual=new Date();
            
            //if(fecha_inicio_listas<=fecha_actual && fecha_fin_listas>=fecha_actual){
                var tr = document.createElement("tr");
                tr.setAttribute("id",convocatorias[i].id_convocatoria);
                
                var id=document.createElement("td");
                id.innerHTML=convocatorias[i].id_convocatoria;
                tr.appendChild(id);
    
                var n_movilidades=document.createElement("td");
                n_movilidades.innerHTML=convocatorias[i].n_movilidades;
                tr.appendChild(n_movilidades);
    
                var tipo=document.createElement("td");
                tipo.innerHTML=convocatorias[i].tipo;
                tr.appendChild(tipo);
    
                var pais=document.createElement("td");
                pais.innerHTML=convocatorias[i].pais;
                tr.appendChild(pais);
    
                var verMasContainer=document.createElement("td");
    
                var btnVerMas=document.createElement("button");
                btnVerMas.innerHTML="Enviar Listas Definitivas";
                
                btnVerMas.setAttribute("onclick","enviarLista(event,this)")
                verMasContainer.appendChild(btnVerMas);
                tr.appendChild(verMasContainer);
    
                document.getElementById('convocatoriaTabla').childNodes[3].appendChild(tr);
            //}
        }
    });
}

function borrarTabla(){
    if ( document.getElementById('convocatoriaTabla').childNodes[3].hasChildNodes() ){
        while ( document.getElementById('convocatoriaTabla').childNodes[3].childNodes.length >= 1 ){
            document.getElementById('convocatoriaTabla').childNodes[3].removeChild( document.getElementById('convocatoriaTabla').childNodes[3].firstChild );
        }
    }
}

function volver(pantalla){
    window.location.href = "http://localhost/BECASERASMUS/index.php?vista="+pantalla;
}

function cerrarSesion(){
    fetch('api/cerrarSesion.php')
    .then(response => response.text())
    .then(data => {
        var url = new URL(window.location.href);
        url.searchParams.set('vista', 'inici');
        window.history.replaceState({}, document.title, url.href);
        location.reload();
    });
}