<?php 
    class candidatoRep{
        public static function crearCandidato($dni,$password,$fecha_nac,$nombre,$ap1,$ap2,$grupo,$tfno,$email,$domicilio,$dni_tutor){
            $candidato=new Candidato($dni,$password,$fecha_nac,$nombre,$ap1,$ap2,$grupo,$tfno,$email,$domicilio,$dni_tutor);
            return $candidato;
        }
    }
?>