<?php 
    class idioma_item_baremableRep{
        public static function crearIdioma_item_baremable($idIdiomaBaremo, $idIdioma, $idConvocatoria, $nota){
            $idioma_item_baremable=new Idioma_Baremo_Convocatoria($idIdiomaBaremo, $idIdioma, $idConvocatoria, $nota);
            return $idioma_item_baremable;
        }

    }
?>