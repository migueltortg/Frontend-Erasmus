<?php 
    
    class convocatoriaRep{

        public static function crearConvocatoria($id_convocatoria,$n_movilidades,$tipo,$f_inicio_solicitudes,$f_fin_solicitudes
        ,$f_inicio_pruebas_seleccion,$f_fin_pruebas_seleccion,$f_inicio_listas_definitivas,$f_fin_listas_definitivas,$pais,$proyecto_cod){
            
            $convocatoria=new Convocatoria($id_convocatoria,$n_movilidades,$tipo,$f_inicio_solicitudes,$f_fin_solicitudes
            ,$f_inicio_pruebas_seleccion,$f_fin_pruebas_seleccion,$f_inicio_listas_definitivas,
            $f_fin_listas_definitivas,$pais,$proyecto_cod);

            return $convocatoria;
        }

        public static function arrayConvocatoria($array){
            $arrayConvocatoria=array();
            foreach ($array as $objeto) {
                array_push($arrayConvocatoria,convocatoriaRep::crearConvocatoria($objeto->ID_CONVOCATORIA,$objeto->N_MOVILIDADES,
                $objeto->TIPO,$objeto->F_INICIO_SOLICITUDES,$objeto->F_FIN_SOLICITUDES
                ,$objeto->F_INICIO_PRUEBAS_SELECCION,$objeto->F_FIN_PRUEBAS_SELECCION,
                $objeto->F_INICIO_LISTAS_DEFINITIVAS,$objeto->F_FIN_LISTAS_DEFINITIVAS,$objeto->PAIS,$objeto->FK_PROYECTO_COD));
            }
            return $arrayConvocatoria;
        }
        
        // public static function crearPDF($convocatoria){

        //     $html= "
        //     <html>
        //     <head>
        //     <meta http-equiv='Content-Type' content='text/html; charset=UTF-8'W/>
        //     <title>Pedazo de PDF</title>
        //     </head>
        //     <body>
        //     <p>TU PUTA MADRE DIEGO</p>
        //     </body>
        // ";

        // $mipdf = new Dompdf();
        // $mipdf->getOptions()->setChroot($_SERVER['DOCUMENT_ROOT']);

        // # Definimos el tamaño y orientación del papel que queremos.
        // # O por defecto cogerá el que está en el fichero de configuración.
        // $mipdf ->setpaper("A4", "portrait");
        // # Cargamos el contenido HTML.
        // $mipdf ->loadhtml($html);

        // # Renderizamos el documento PDF.
        // $mipdf ->render();

        // # Creamos un fichero
        // $pdf = $mipdf->output();
        // $filename = "HeavenTicket.pdf";
        // file_put_contents($filename, $pdf);

        // # Enviamos el fichero PDF al navegador.
        // $mipdf->stream($filename, ["Attachment"=>0]);
        // }
    }
?>