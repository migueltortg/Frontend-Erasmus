<?php 
    class item_baremableRep{

        public static function crearItem_baremable($id,$nombre){
            $item_baremable=new Item_Baremable($id,$nombre);
            return $item_baremable;
        }

        public static function arrayItem_baremable($array){
            $arrayItem_baremable=array();
            foreach ($array as $objeto) {
                array_push($arrayItem_baremable,item_baremableRep::crearItem_baremable($objeto->ID_ITEM_BAREMABLE,$objeto->NOMBRE));
            }
            return $arrayItem_baremable;
        }
    }
?>