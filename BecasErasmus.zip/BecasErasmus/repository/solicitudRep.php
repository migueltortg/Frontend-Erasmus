<?php 
    class solicitudRep{
        public static function crearSolicitud($id_solicitud,$dni_candidato,$id_convocatoria,$grupo,$tfno,$email,$domicilio,$urlFoto){
            $solicitud=new Solicitud($id_solicitud,$dni_candidato,$id_convocatoria,$grupo,$tfno,$email,$domicilio,$urlFoto);
            return $solicitud;
        }

        public static function arraySolicitud($array){
            $arraySolicitud=array();
            foreach ($array as $objeto) {
                array_push($arraySolicitud,solicitudRep::crearSolicitud($objeto->ID_SOLICITUD,$objeto->DNI_CANDIDATO,
                $objeto->ID_CONVOCATORIA,$objeto->GRUPO,$objeto->TFNO,$objeto->EMAIL,$objeto->DOMICILIO,$objeto->urlFoto));
            }
            return $arraySolicitud;
        }
    }
?>