<?php 
    class proyectoRep{

        public static function crearProyecto($cod_proyecto,$nombre,$proyecto_inicio,$proyecto_fin){
            $proyecto=new Proyecto($cod_proyecto,$nombre,$proyecto_inicio,$proyecto_fin);
            return $proyecto;
        }

        public static function arrayProyecto($array){
            $arrayProyecto=array();
            foreach ($array as $objeto) {
                array_push($arrayProyecto,proyectoRep::crearProyecto($objeto->COD_PROYECTO,$objeto->NOMBRE,$objeto->PROYECTO_INICIO
                ,$objeto->PROYECTO_FIN));
            }
            return $arrayProyecto;
        }
    }
?>