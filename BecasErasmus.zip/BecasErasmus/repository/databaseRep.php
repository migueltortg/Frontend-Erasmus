<?php 
    class databaseRep{
        public static function selectUniversal($conexion,$tabla){
            
            $resultado = $conexion->query('SELECT * FROM '.$tabla.";", MYSQLI_USE_RESULT);
            $objetos=array();
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($objetos,$registro);
            }  
    
            switch (strtoupper($tabla)) {
                case "ITEM_BAREMABLE":
                    return item_BaremableRep::arrayItem_baremable($objetos);
                    break;
                case "PROYECTO":
                    return proyectoRep::arrayProyecto($objetos);
                    break;
                case "CONVOCATORIA":
                    return convocatoriaRep::arrayConvocatoria($objetos);
                    break;
                case "SOLICITUD":
                    return solicitudRep::arraySolicitud($objetos);
                    break;
                default:
                    return $objetos;
                    break;
            }
        }

        public static function introducirConvocatoria($conexion,$convocatoria){
            $preparedConexion=$conexion->prepare("INSERT INTO CONVOCATORIA (
                N_MOVILIDADES,
                TIPO,
                F_INICIO_SOLICITUDES,
                F_FIN_SOLICITUDES,
                F_INICIO_PRUEBAS_SELECCION,
                F_FIN_PRUEBAS_SELECCION,
                F_INICIO_LISTAS_DEFINITIVAS,
                F_FIN_LISTAS_DEFINITIVAS,
                PAIS,
                FK_PROYECTO_COD
            ) VALUES (
                :N_MOVILIDADES,
                :TIPO,
                :F_INICIO_SOLICITUDES,
                :F_FIN_SOLICITUDES,
                :F_INICIO_PRUEBAS_SELECCION,
                :F_FIN_PRUEBAS_SELECCION,
                :F_INICIO_LISTAS_DEFINITIVAS,
                :F_FIN_LISTAS_DEFINITIVAS,
                :PAIS,
                :FK_PROYECTO_COD
            );");
    
            $N_MOVILIDADES=$convocatoria->get_n_movilidades();
            $TIPO=$convocatoria->get_tipo();
            $F_INICIO_SOLICITUDES=$convocatoria->get_f_inicio_solicitudes();
            $F_FIN_SOLICITUDES=$convocatoria->get_f_fin_solicitudes();
            $F_INICIO_PRUEBAS_SELECCION=$convocatoria->get_f_inicio_pruebas_seleccion();
            $F_FIN_PRUEBAS_SELECCION=$convocatoria->get_f_fin_pruebas_seleccion();
            $F_INICIO_LISTAS_DEFINITIVAS=$convocatoria->get_f_inicio_listas_definitivas();
            $F_FIN_LISTAS_DEFINITIVAS=$convocatoria->get_f_fin_listas_definitivas();
            $PAIS=$convocatoria->get_pais();
            $FK_PROYECTO_COD=$convocatoria->get_proyecto_cod();
    
    
            $preparedConexion->bindParam(':N_MOVILIDADES',$N_MOVILIDADES);
            $preparedConexion->bindParam(':TIPO',$TIPO);
            $preparedConexion->bindParam(':F_INICIO_SOLICITUDES',$F_INICIO_SOLICITUDES);
            $preparedConexion->bindParam(':F_FIN_SOLICITUDES',$F_FIN_SOLICITUDES);
            $preparedConexion->bindParam(':F_INICIO_PRUEBAS_SELECCION',$F_INICIO_PRUEBAS_SELECCION);
            $preparedConexion->bindParam(':F_FIN_PRUEBAS_SELECCION',$F_FIN_PRUEBAS_SELECCION);
            $preparedConexion->bindParam(':F_INICIO_LISTAS_DEFINITIVAS',$F_INICIO_LISTAS_DEFINITIVAS);
            $preparedConexion->bindParam(':F_FIN_LISTAS_DEFINITIVAS',$F_FIN_LISTAS_DEFINITIVAS);
            $preparedConexion->bindParam(':PAIS',$PAIS);
            $preparedConexion->bindParam(':FK_PROYECTO_COD',$FK_PROYECTO_COD);
    
            $preparedConexion->execute();
        }

        public static function idUltConvocatoria($conexion){
            $resultado = $conexion->query("SELECT * FROM CONVOCATORIA ORDER BY ID_CONVOCATORIA DESC LIMIT 1;", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return $registro->ID_CONVOCATORIA;
            } 
        }

        public static function introducirIdioma_item_baremable($conexion,$item){
            $preparedConexion=$conexion->prepare("INSERT INTO IDIOMA_BAREMO_CONVOCATORIA (ID_IDIOMA, ID_CONVOCATORIA, NOTA)
            VALUES (:idIdioma, :idConvocatoria, :nota);");
    
            $idIdioma=$item->getIdIdioma();
            $idConvocatoria=$item->getIdConvocatoria();
            $nota=$item->getNota();

            $preparedConexion->bindParam(':idIdioma',$idIdioma);
            $preparedConexion->bindParam(':idConvocatoria',$idConvocatoria);
            $preparedConexion->bindParam(':nota',$nota);
    
            $preparedConexion->execute();
        }

        public static function introducirItemConvocatoria($conexion,$array){
            foreach($array as $item){
                $preparedConexion=$conexion->prepare("INSERT INTO CONVOCATORIA_ITEM (
                    ID_CONVOCATORIA,
                    ID_ITEM,
                    OBLIGATORIO,
                    PRESENTA_USER,
                    VALOR_MIN,
                    VALOR_MAX
                )
                VALUES (:ID_CONVOCATORIA, :ID_ITEM, :OBLIGATORIO, :PRESENTA_USER, :VALOR_MIN, :VALOR_MAX);");
        
                $ID_CONVOCATORIA=$item->get_id_convocatoria();
                $ID_ITEM=$item->get_id_item();
                if($item->get_obligatorio()=="true"){
                    $OBLIGATORIO=true;
                }else{
                    $OBLIGATORIO=false;
                }
                if($item->get_presentaUser()=="true"){
                    $PRESENTA_USER=true;
                }else{
                    $PRESENTA_USER=false;
                }

                $VALOR_MIN=$item->get_valor_min();
                $VALOR_MAX=$item->get_valor_max();

                $preparedConexion->bindParam(':ID_CONVOCATORIA',$ID_CONVOCATORIA);
                $preparedConexion->bindParam(':ID_ITEM',$ID_ITEM);
                $preparedConexion->bindParam(':OBLIGATORIO',$OBLIGATORIO);
                $preparedConexion->bindParam(':PRESENTA_USER',$PRESENTA_USER);
                $preparedConexion->bindParam(':VALOR_MIN',$VALOR_MIN);
                $preparedConexion->bindParam(':VALOR_MAX',$VALOR_MAX);
        
                $preparedConexion->execute();
            }
        }

        public static function devolverUser($conexion,$dni,$password){
            $coordinador=databaseRep::devolverCoordinador($conexion,$dni,$password);
            $candidato=databaseRep::devolverCandidato($conexion,$dni,$password);

            if(isset($candidato)){
                return $candidato;
            }else if(isset($coordinador)){
                return $coordinador;
            }else{
                return null;
            }
        }

        public static function devolverCoordinador($conexion,$dni,$password){
            $resultado = $conexion->query("SELECT * FROM COORDINADOR WHERE DNI='".$dni."' AND PASSWORD='".$password."';", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return coordinadorRep::crearCoordinador($registro->DNI,$registro->PASSWORD,$registro->FECHA_NAC,$registro->NOMBRE,$registro->AP1,$registro->AP2,$registro->TFNO,
                $registro->EMAIL,$registro->DOMICILIO);
            } 
        }

        public static function devolverCandidato($conexion,$dni,$password){
            $resultado = $conexion->query("SELECT * FROM CANDIDATO WHERE DNI='".$dni."' AND PASSWORD='".$password."';", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return candidatoRep::crearCandidato($registro->DNI,$registro->PASSWORD,$registro->FECHA_NAC,$registro->NOMBRE,$registro->AP1,$registro->AP2,
                $registro->GRUPO,$registro->TFNO,$registro->EMAIL,$registro->DOMICILIO,$registro->FK_TUTOR_DNI);
            } 
        }

        public static function introducirTutor($conexion,$tutor){
            $preparedConexion=$conexion->prepare("INSERT INTO TUTOR (DNI_TUTOR, NOMBRE, AP1,AP2,TFNO,DOMICILIO)
            VALUES (:DNI_TUTOR, :NOMBRE, :AP1,:AP2,:TFNO,:DOMICILIO);");
    
            $DNI_TUTOR=$tutor->get_dni_tutor();
            $NOMBRE=$tutor->get_nombre();
            $AP1=$tutor->get_ap1();
            $AP2=$tutor->get_ap2();
            $TFNO=$tutor->get_tfno();
            $DOMICILIO=$tutor->get_domicilio();

            $preparedConexion->bindParam(':DNI_TUTOR',$DNI_TUTOR);
            $preparedConexion->bindParam(':NOMBRE',$NOMBRE);
            $preparedConexion->bindParam(':AP1',$AP1);
            $preparedConexion->bindParam(':AP2',$AP2);
            $preparedConexion->bindParam(':TFNO',$TFNO);
            $preparedConexion->bindParam(':DOMICILIO',$DOMICILIO);
    
            $preparedConexion->execute();
        }

        public static function idUltTutor($conexion,$dni){
            $resultado = $conexion->query("SELECT * FROM Tutor where DNI_TUTOR='".$dni."' LIMIT 1;", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return $registro->DNI_TUTOR;
            } 
        }

        public static function solicitudID($conexion,$idSolicitud){
            $resultado = $conexion->query("SELECT * FROM SOLICITUD where ID_SOLICITUD='".$idSolicitud."';", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return solicitudRep::crearSolicitud($registro->ID_SOLICITUD,$registro->DNI_CANDIDATO,
                $registro->ID_CONVOCATORIA,$registro->GRUPO,$registro->TFNO,$registro->EMAIL,$registro->DOMICILIO,$registro->urlFoto);
            } 
        }

        public static function candidatoID($conexion,$dni){
            $resultado = $conexion->query("SELECT * FROM CANDIDATO where DNI='".$dni."';", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return candidatoRep::crearCandidato($registro->DNI,$registro->PASSWORD,$registro->FECHA_NAC,$registro->NOMBRE
                ,$registro->AP1,$registro->AP2,$registro->GRUPO,$registro->TFNO,$registro->EMAIL,$registro->DOMICILIO,$registro->FK_TUTOR_DNI);
            } 
        }

        public static function introducirCandidato($conexion,$candidato){
            $preparedConexion=$conexion->prepare("INSERT INTO CANDIDATO (DNI, PASSWORD, FECHA_NAC,NOMBRE,AP1,AP2,GRUPO,TFNO,EMAIL,DOMICILIO,FK_TUTOR_DNI)
            VALUES (:DNI, :PASSWORD, :FECHA_NAC,:NOMBRE,:AP1,:AP2,:GRUPO, :TFNO, :EMAIL,:DOMICILIO,:FK_TUTOR_DNI);");
    
            $DNI=$candidato->get_dni();
            $PASSWORD=$candidato->get_password();
            $FECHA_NAC=$candidato->get_fecha_nac();
            $NOMBRE=$candidato->get_nombre();
            $AP1=$candidato->get_ap1();
            $AP2=$candidato->get_ap2();
            $GRUPO=$candidato->get_grupo();
            $TFNO=$candidato->get_tfno();
            $EMAIL=$candidato->get_email();
            $DOMICILIO=$candidato->get_domicilio();
            $FK_TUTOR_DNI=$candidato->get_dni_tutor();

            $preparedConexion->bindParam(':DNI',$DNI);
            $preparedConexion->bindParam(':PASSWORD',$PASSWORD);
            $preparedConexion->bindParam(':FECHA_NAC',$FECHA_NAC);
            $preparedConexion->bindParam(':NOMBRE',$NOMBRE);
            $preparedConexion->bindParam(':AP1',$AP1);
            $preparedConexion->bindParam(':AP2',$AP2);
            $preparedConexion->bindParam(':GRUPO',$GRUPO);
            $preparedConexion->bindParam(':TFNO',$TFNO);
            $preparedConexion->bindParam(':EMAIL',$EMAIL);
            $preparedConexion->bindParam(':DOMICILIO',$DOMICILIO);
            $preparedConexion->bindParam(':FK_TUTOR_DNI',$FK_TUTOR_DNI);
    
            $preparedConexion->execute();
        }

        public static function introducirGrupo_Convocatoria($conexion,$idConvocatoria,$idGrupo){
            $preparedConexion=$conexion->prepare("INSERT INTO GRUPO_CONVOCATORIA (ID_CONVOCATORIA, ID_GRUPO)
            VALUES (:ID_CONVOCATORIA, :ID_GRUPO);");

            $preparedConexion->bindParam(':ID_CONVOCATORIA',$idConvocatoria);
            $preparedConexion->bindParam(':ID_GRUPO',$idGrupo);
    
            $preparedConexion->execute();
        }

        public static function introducirProyecto($conexion,$proyecto){
            $preparedConexion=$conexion->prepare("INSERT INTO PROYECTO (NOMBRE, PROYECTO_INICIO, PROYECTO_FIN)
            VALUES (:NOMBRE, :PROYECTO_INICIO, :PROYECTO_FIN);");

            $NOMBRE=$proyecto->get_nombre();
            $PROYECTO_INICIO=$proyecto->get_proyecto_inicio();
            $PROYECTO_FIN=$proyecto->get_proyecto_fin();

            $preparedConexion->bindParam(':NOMBRE',$NOMBRE);
            $preparedConexion->bindParam(':PROYECTO_INICIO',$PROYECTO_INICIO);
            $preparedConexion->bindParam(':PROYECTO_FIN',$PROYECTO_FIN);
    
            $preparedConexion->execute();
        }

        public static function rolDNI($conexion,$dni){
            $resultado = $conexion->query("SELECT * FROM COORDINADOR WHERE DNI='".$dni."';", MYSQLI_USE_RESULT);
            
            $role="user";
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                $role="coordinador";
            } 
            return $role;
        }

        public static function item_convocatoria($conexion,$idConvocatoria){
            $resultado = $conexion->query("SELECT *
            FROM CONVOCATORIA_ITEM
            JOIN ITEM_BAREMABLE ON CONVOCATORIA_ITEM.ID_ITEM = ITEM_BAREMABLE.ID_ITEM_BAREMABLE
            WHERE CONVOCATORIA_ITEM.ID_CONVOCATORIA = '".$idConvocatoria."';"
            , MYSQLI_USE_RESULT);
            
            $arrayItem=array();
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($arrayItem,$registro);
            } 
            return $arrayItem;
        }

        public static function item_convocatoriaID($conexion,$idConvocatoria){
            $resultado = $conexion->query("SELECT * FROM CONVOCATORIA_ITEM WHERE 
            ID_CONVOCATORIA = '".$idConvocatoria."';", MYSQLI_USE_RESULT);
            
            $arrayItem=array();
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($arrayItem,item_convocatoriaRep::crearItem_Convocatoria($registro->ID_CONVOCATORIA_ITEM,
                $registro->ID_CONVOCATORIA,$registro->ID_ITEM,$registro->OBLIGATORIO,$registro->PRESENTA_USER,
                $registro->VALOR_MIN,$registro->VALOR_MAX));
            } 
            return $arrayItem;
        }

        public static function convocatoriaTipo($conexion,$tipo){
            $resultado = $conexion->query("select * from grupo_convocatoria g inner join convocatoria c on 
            g.id_convocatoria=c.id_convocatoria where g.id_grupo='".$tipo."';
            ", MYSQLI_USE_RESULT);
            
            $arrayConvocatoria=array();
            while ($objeto = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($arrayConvocatoria,convocatoriaRep::crearConvocatoria($objeto->ID_CONVOCATORIA,$objeto->N_MOVILIDADES,
                $objeto->TIPO,$objeto->F_INICIO_SOLICITUDES,$objeto->F_FIN_SOLICITUDES
                ,$objeto->F_INICIO_PRUEBAS_SELECCION,$objeto->F_FIN_PRUEBAS_SELECCION,
                $objeto->F_INICIO_LISTAS_DEFINITIVAS,$objeto->F_FIN_LISTAS_DEFINITIVAS,$objeto->PAIS,$objeto->FK_PROYECTO_COD));
            } 
            return $arrayConvocatoria;
        }

        public static function solicitudTipo($conexion,$tipo){
            $resultado = $conexion->query("select * from SOLICITUD where grupo='".$tipo."';", MYSQLI_USE_RESULT);
            
            $arraySolicitud=array();
            while ($objeto = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($arraySolicitud,solicitudRep::crearSolicitud($objeto->ID_SOLICITUD,$objeto->DNI_CANDIDATO,
                $objeto->ID_CONVOCATORIA,$objeto->GRUPO,$objeto->TFNO,$objeto->EMAIL,$objeto->DOMICILIO,$objeto->urlFoto));
            } 
            return $arraySolicitud;
        }

        public static function modificarNota($conexion,$idSolicitud,$idItem,$nota){
            $preparedConexion=$conexion->prepare("UPDATE BAREMACION SET NOTA='".$nota."' WHERE ID_ITEM='".$idItem."' 
            AND ID_SOLICITUD='".$idSolicitud."';");
    
            $preparedConexion->execute();
        }

        public static function eliminarConvocatoria($conexion,$idConvocatoria){
            $preparedConexion=$conexion->prepare("delete from convocatoria where id_convocatoria=".$idConvocatoria.";");
    
            $preparedConexion->execute();
        }

        public static function notaBaremacion($conexion,$idSolicitud,$idItem){
            $resultado = $conexion->query("SELECT * FROM BAREMACION WHERE 
            ID_ITEM = '".$idItem."' AND ID_SOLICITUD='".$idSolicitud."';", MYSQLI_USE_RESULT);
            
            $nota=0;
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                $nota=$registro->NOTA;
            } 
            return $nota;
        }

        public static function introducirSolicitud($conexion,$solicitud){
            $preparedConexion=$conexion->prepare("INSERT INTO SOLICITUD (DNI_CANDIDATO, ID_CONVOCATORIA, GRUPO, TFNO, EMAIL, DOMICILIO, urlFoto)
            VALUES (:DNI_CANDIDATO, :ID_CONVOCATORIA, :GRUPO, :TFNO, :EMAIL, :DOMICILIO, :urlFoto);");

            $DNI_CANDIDATO=$solicitud->get_dni_candidato();
            $ID_CONVOCATORIA=$solicitud->get_id_convocatoria();
            $GRUPO=$solicitud->get_grupo();
            $TFNO=$solicitud->get_tfno();
            $EMAIL=$solicitud->get_email();
            $DOMICILIO=$solicitud->get_domicilio();
            $URLFOTO=$solicitud->get_urlFoto();

            $preparedConexion->bindParam(':DNI_CANDIDATO',$DNI_CANDIDATO);
            $preparedConexion->bindParam(':ID_CONVOCATORIA',$ID_CONVOCATORIA);
            $preparedConexion->bindParam(':GRUPO',$GRUPO);
            $preparedConexion->bindParam(':TFNO',$TFNO);
            $preparedConexion->bindParam(':EMAIL',$EMAIL);
            $preparedConexion->bindParam(':DOMICILIO',$DOMICILIO);
            $preparedConexion->bindParam(':urlFoto',$URLFOTO);
    
            $preparedConexion->execute();
        }

        public static function valorIdioma($conexion,$titulo,$idConvocatoria){
            $resultado = $conexion->query("select * from idioma_baremo_convocatoria a inner join idioma i on a.id_idioma=i.id_idioma 
            where a.id_convocatoria='".$idConvocatoria."' AND i.nivel='".$titulo."';
            ", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return $registro->NOTA;
            } 
        }

        public static function idUltSolicitud($conexion,$email){
            $resultado = $conexion->query("SELECT * FROM SOLICITUD where email='".$email."' order by id_solicitud desc LIMIT 1;", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return $registro->ID_SOLICITUD;
            } 
        }

        public static function introducirBaremacion($conexion,$baremacion){
            $preparedConexion=$conexion->prepare("INSERT INTO BAREMACION (ID_ITEM, ID_SOLICITUD, NOTA, URL)
            VALUES (:ID_ITEM, :ID_SOLICITUD, :NOTA, :URL);");

            $ID_ITEM=$baremacion->get_id_item();
            $ID_SOLICITUD=$baremacion->get_id_solicitud();
            $NOTA=$baremacion->get_nota();
            $URL=$baremacion->get_url();

            $preparedConexion->bindParam(':ID_ITEM',$ID_ITEM);
            $preparedConexion->bindParam(':ID_SOLICITUD',$ID_SOLICITUD);
            $preparedConexion->bindParam(':NOTA',$NOTA);
            $preparedConexion->bindParam(':URL',$URL);
    
            $preparedConexion->execute();
        }

        public static function devolverConvocatoria($conexion,$idConvocatoria){
            $resultado = $conexion->query("SELECT * FROM CONVOCATORIA where ID_CONVOCATORIA='".$idConvocatoria."';", MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return convocatoriaRep::crearConvocatoria($registro->ID_CONVOCATORIA,$registro->N_MOVILIDADES,$registro->TIPO,$registro->F_INICIO_SOLICITUDES,
                $registro->F_FIN_SOLICITUDES,$registro->F_INICIO_PRUEBAS_SELECCION,$registro->F_FIN_PRUEBAS_SELECCION,
                $registro->F_INICIO_LISTAS_DEFINITIVAS,$registro->F_FIN_LISTAS_DEFINITIVAS,$registro->PAIS,$registro->FK_PROYECTO_COD);
            } 
        }

        public static function selectAdmitidos($conexion,$id){
            $resultado = $conexion->query("select * from baremacion b inner join solicitud s on s.id_solicitud=b.id_solicitud 
            inner join candidato c on s.dni_candidato=c.dni  
            inner join convocatoria o on o.id_convocatoria=s.id_convocatoria
            where s.id_convocatoria=".$id." group by b.id_solicitud;", MYSQLI_USE_RESULT);
            
            $arrayCandidatos=array();
            $i=1;
            while ($objeto = $resultado->fetch(PDO::FETCH_OBJ)) {
                if($i<=$objeto->N_MOVILIDADES){
                    $candidato=array();
                    array_push($candidato,$objeto->DNI);
                    array_push($candidato,$objeto->NOMBRE." ".$objeto->AP1." ".$objeto->AP2);
                    array_push($candidato,databaseRep::notaSolicitud($conexion,$objeto->ID_SOLICITUD));
                    array_push($arrayCandidatos,$candidato);
                }
                $i++;
            } 
            return $arrayCandidatos;
        }

        public static function selectReservas($conexion,$id){
            $resultado = $conexion->query("select * from baremacion b inner join solicitud s on s.id_solicitud=b.id_solicitud 
            inner join candidato c on s.dni_candidato=c.dni  
            inner join convocatoria o on o.id_convocatoria=s.id_convocatoria
            where s.id_convocatoria=".$id." group by b.id_solicitud;", MYSQLI_USE_RESULT);
            
            $arrayCandidatos=array();
            $i=1;
            while ($objeto = $resultado->fetch(PDO::FETCH_OBJ)) {
                if($i>$objeto->N_MOVILIDADES){
                    $candidato=array();
                    array_push($candidato,$objeto->DNI);
                    array_push($candidato,$objeto->NOMBRE." ".$objeto->AP1." ".$objeto->AP2);
                    array_push($candidato,databaseRep::notaSolicitud($conexion,$objeto->ID_SOLICITUD));
                    array_push($arrayCandidatos,$candidato);
                }
                $i++;
            } 
            return $arrayCandidatos;
        }

        public static function notaSolicitud($conexion,$id){
            $resultado = $conexion->query("select sum(nota) as suma from baremacion b inner join solicitud s 
            on b.id_solicitud=s.id_solicitud where s.id_solicitud=".$id.";", MYSQLI_USE_RESULT);
            
            while ($objeto = $resultado->fetch(PDO::FETCH_OBJ)) {
                if($objeto->suma==null){
                    $nota=0;
                }else{
                    $nota=$objeto->suma;
                }
            } 
            return $nota;
        }
    }
?>