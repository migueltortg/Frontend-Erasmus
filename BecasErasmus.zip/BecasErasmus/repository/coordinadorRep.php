<?php 
    class coordinadorRep{
        public static function crearCoordinador($dni,$password,$fecha_nac,$nombre,$ap1,$ap2,$tfno,$email,$domicilio){
            $coordinador=new Coordinador($dni,$password,$fecha_nac,$nombre,$ap1,$ap2,$tfno,$email,$domicilio);
            return $coordinador;
        }
    }
?>