<?php 
    class item_convocatoriaRep{

        public static function crearItem_Convocatoria($id_convocatoria_item,$id_convocatoria,$id_item,$obligatorio,$presentaUser,$valor_min,$valor_max){
            
            $Convocatoria_Item=new Convocatoria_Item($id_convocatoria_item,$id_convocatoria,$id_item,$obligatorio,$presentaUser,$valor_min,$valor_max);

            return $Convocatoria_Item;
        }
    }
?>