<?php 
    class baremacionRep{
        public static function crearBaremacion($id_baremacion,$id_item,$id_solicitud,$nota,$url){
            $baremacion=new Baremacion($id_baremacion,$id_item,$id_solicitud,$nota,$url);
            return $baremacion;
        }
    }
?>