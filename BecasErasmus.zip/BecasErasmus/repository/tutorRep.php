<?php 
    class tutorRep{
        public static function crearTutor($dni_tutor,$nombre,$ap1,$ap2,$tfno,$domicilio){
            $tutor=new Tutor($dni_tutor,$nombre,$ap1,$ap2,$tfno,$domicilio);
            return $tutor;
        }
    }
?>