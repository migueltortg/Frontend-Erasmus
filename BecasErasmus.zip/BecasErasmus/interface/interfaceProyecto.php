<?php 
    class interfaceProyecto{
        public static function cargarSelect($conexion){
            $proyectos=databaseRep::selectUniversal($conexion,"PROYECTO");
            
            foreach($proyectos as $proyecto){
                echo "
                    <option value='".$proyecto->get_cod_proyecto()."'>".$proyecto->get_nombre()."</option>
                ";
            }
        }   
    }
?>