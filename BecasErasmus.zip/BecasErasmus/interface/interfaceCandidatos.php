<?php 
    class interfaceCandidatos{
        public static function filasAdmitidos($conexion,$idConvocatoria){
            $candidatos=databaseRep::selectAdmitidos($conexion,$idConvocatoria);
            usort($candidatos, 'self::compararNota'); 
            $text="";
            $i=1;
            foreach($candidatos as $candidato){
                $text= $text . "
                    <tr>
                        <td>".$i."</td>
                        <td>".$candidato[0]."</td>
                        <td>".$candidato[1]."</td>
                        <td>".$candidato[2]."</td>
                    </tr>
                ";
                $i++;
            }
            return $text;
        }   

        public static function filasReservas($conexion,$idConvocatoria){
            $candidatos=databaseRep::selectReservas($conexion,$idConvocatoria);
            usort($candidatos, 'self::compararNota'); 
            $text="";
            $i=1;
            foreach($candidatos as $candidato){
                $text= $text . "
                    <tr>
                        <td>".$i."</td>
                        <td>".$candidato[0]."</td>
                        <td>".$candidato[1]."</td>
                        <td>".$candidato[2]."</td>
                    </tr>
                ";
                $i++;
            }
            return $text;
        }  

        public static function compararNota($a,$b){
            return $b['2']-$a['2'];
        }
    }
?>