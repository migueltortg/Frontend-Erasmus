<?php 
    class interfaceConvocatoria{
        public static function cargarTabla($conexion){
            $convocatorias=databaseRep::selectUniversal($conexion,"Convocatoria");
            $html="
                <table border='1px' id='convocatoriaTabla'>
                    <thead>
                        <tr>
                            <th>ID_CONVOCATORIA</th>
                            <th>N_MOVILIDADES</th>
                            <th>TIPO</th>
                            <th>PAIS</th>
                        </tr>
                    </thead>
                    <tbody>
            ";
            foreach($convocatorias as $convocatoria){
                $html=$html . "
                    <tr id='".$convocatoria->get_id_convocatoria()."'>
                        <td>".$convocatoria->get_id_convocatoria()."</td>
                        <td>".$convocatoria->get_n_movilidades()."</td>
                        <td>".$convocatoria->get_tipo()."</td>
                        <td>".$convocatoria->get_pais()."</td>
                        <td><button onclick='borrar(event,this)'>Borrar</button></td>
                    </tr>
                ";
            }

            $html=$html."
                    </tbody>
                </table>
            ";

            return $html;
        }   
    }
?>