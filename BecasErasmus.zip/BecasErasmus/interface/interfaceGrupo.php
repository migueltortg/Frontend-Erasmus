<?php 
    class interfaceGrupo{
        public static function cargarSelect($conexion){
            $grupos=databaseRep::selectUniversal($conexion,"Grupo");
            
            foreach($grupos as $grupo){
                echo "
                    <option value='".$grupo->CLAVE."' id='".$grupo->CLAVE."'>".$grupo->CLAVE."</option>
                ";
            }
        }   
    }
?>