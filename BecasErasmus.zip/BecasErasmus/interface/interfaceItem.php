<?php 
    class interfaceItem{
        public static function cargarTabla($conexion){
            $items_baremable=databaseRep::selectUniversal($conexion,"ITEM_BAREMABLE");
            foreach($items_baremable as $item){
                echo "
                    <tr id='".$item->get_id_item_baremable()."'>
                        <td><input type='checkbox'></td>
                        <td><p>".$item->get_id_item_baremable()."</p></td>
                        <td><p>".$item->get_nombre()."</p></td>
                        <td><input type='number' min='0' name='valor_max".$item->get_id_item_baremable()."' value='0'></td>
                        <td><input type='number' min='0' name='valor_min".$item->get_id_item_baremable()."' value='0'></td>
                        <td>
                            <select name='obligatorio".$item->get_id_item_baremable()."'>
                                <option value='true'>SI</option>
                                <option value='false'>NO</option>
                            </select>
                        </td>
                        <td>
                            <select name='presentaUser".$item->get_id_item_baremable()."'>
                                <option value='true'>SI</option>
                                <option value='false'>NO</option>
                            </select>
                        </td>
                    </tr>
                ";
            }
        }   

        public static function cargarForm($conexion,$idConvocatoria){
            $items=databaseRep::item_convocatoria($conexion,$idConvocatoria);
            foreach($items as $item){
                $idInput="";
                if($item->PRESENTA_USER==1){
                    switch($item->ID_ITEM){
                        case "1":
                            $idInput="inputIdioma";
                            echo "
                                <label for='inputIdioma'>Certificado de Idioma: </label>
                                    <input accept='application/pdf' type='file' name='inputIdioma' id='inputIdioma' class='inputFile'>
                                    <button onclick='verPDF(event,".$idInput.")'>Ver Documento</button>
                                    <br>
                                    ";
                            break;
                        case "3":
                            $idInput="inputNotas";
                            echo "
                                <label for='inputNotas'>Certificado de Notas: </label>
                                    <input accept='application/pdf' type='file' name='inputsNotas' id='inputNotas' class='inputFile'>
                                    <button onclick='verPDF(event,".$idInput.")'>Ver Documento</button>
                                    <br>
                                    ";
                            break;
                        case "4":
                            $idInput="inputIdoneidad";
                            echo "
                                <label for='inputIdoneidad'>Certificado de Idoneidad: </label>
                                <input accept='application/pdf' type='file' name='inputIdoneidad' id='inputIdoneidad' class='inputFile'>
                                <button onclick='verPDF(event,".$idInput.")'>Ver Documento</button>
                                <br>
                                ";
                            break;
                    }
                }
            }
        }

        public static function cargarSelectIdioma($conexion){
            $idiomas=databaseRep::selectUniversal($conexion,"IDIOMA");
            $html="";
            foreach($idiomas as $idioma){
                $html=$html. "
                    <option value='".$idioma->NIVEL."'>".$idioma->NIVEL."</option>
                ";
            }
            return $html;
        }
    }
?>