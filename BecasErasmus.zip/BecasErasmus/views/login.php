<?php 
    $conexion=DB::getConexion();
    
    if(isset($_POST["iniciarSesion"])){
        //Comprobar credenciales
        $user=databaseRep::devolverUser($conexion,$_POST['dni'],$_POST['contraseña']);
        if($user!=null){//COMPROBAR CONTRASEÑA
            loginRep::logIn($user);
            header("Location: http://localhost/BECASERASMUS/index.php?vista=inicio");
        }else{
            echo "USUARIO O CONTRASEÑA INCORRECTOS";
        }
    }
?>
<head>
    <title>Inicio de Sesion</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/login.css">
</head>
<body>
    <div id="container">
        <form action="" method="post">        
            <h1>Inicio de Sesión</h1>
            <div>
                <h3>DNI</h3>
                <input type="text" name="dni" id="inputNombre">
            </div>
            <div>
                <h3>Contraseña</h3>
                <input type="text" name="contraseña" id="inputContraseña">
            </div>
            <input type="submit" value="Acceder" name="iniciarSesion" id="inputSubmit">
            <a href="?vista=registro">Registrate</a>
        </form>
    </div>
</body>