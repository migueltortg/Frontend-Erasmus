<!-- Vista Formulario Convocatoria -->
<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/crearConvocatoria.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="volver('landingPageCoordinador')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Crear convocatoria</h1>
        </div>
        <form action="api/crearConvocatoria.php" method="POST">
            <!-- DATOS CONVOCATORIA -->
            <div id="parteConvocatoria">
                <label for="NumMovilidades">Número Movilidades:</label>
                <input type="number" name="NumMovilidades" min=1 value=1>
                <label for="TipoMovilidad">Tipo de Movilidad:</label>
                <select name="TipoMovilidad">
                    <option value="CORTA">CORTA</option>
                    <option value="LARGA">LARGA</option>
                </select>
                <label for="f_inicio_solicitudes">Fecha Inicio Solicitudes:</label>
                <input type="datetime-local" name="f_inicio_solicitudes">
                <label for="f_fin_solicitudes">Fecha Fin Solicitudes:</label>
                <input type="datetime-local" name="f_fin_solicitudes">
                <label for="f_inicio_pruebas">Fecha Inicio Pruebas:</label>
                <input type="datetime-local" name="f_inicio_pruebas">
                <label for="f_fin_pruebas">Fecha Fin Pruebas:</label>
                <input type="datetime-local" name="f_fin_pruebas">
                <label for="f_inicio_listas">Fecha Inicio Listas:</label>
                <input type="datetime-local" name="f_inicio_listas">
                <label for="f_fin_listas">Fecha Fin Listas:</label>
                <input type="datetime-local" name="f_fin_listas">
                <label for="pais">Pais:</label>
                <input type="text" name="pais" placeholder="Pais Destino">
                <label for="proyecto">Proyecto: </label>
                <select name="proyecto">
                    <?php 
                        $conexion=DB::getConexion();
                        interfaceProyecto::cargarSelect($conexion);
                    ?>
                </select>
                <label for="grupoAsignar">Grupo: </label>
                <div>
                    <select name="grupoAsignar" id="selectGrupo">
                        <?php 
                            $conexion=DB::getConexion();
                            interfaceGrupo::cargarSelect($conexion);
                        ?>
                    </select>
                <button onclick="añadirGrupo(event)">+</button>
                </div>
                <table border="1px" id="tablaGruposAsig">
                    <thead>
                        <tr>
                            <th>Grupos Asignados</th>
                            <th>Eliminar</th>
                        </tr>
                    </thead>
                    <tbody>

                    </tbody>
                </table>
                <button onclick="siguiente(event)" id="btnSiguiente">Siguiente</button>
            </div>

            <!-- DATOS ITEMS_BAREMABLE -->
            <div id="parteItems">
                <table id="tablaItem">
                    <thead>
                        <tr>
                            <th><p>Seleccionar</p></th>
                            <th><p>ID Item</p></th>
                            <th><p>Nombre</p></th>
                            <th><p>Valor Máximo</p></th>
                            <th><p>Valor Mínimo</p></th>
                            <th><p>Obligatorio</p></th>
                            <th><p>Presenta Usuario</p></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            $conexion=DB::getConexion();
                            interfaceItem::cargarTabla($conexion);
                        ?>
                    </tbody>
                </table>

                <!-- AQUI TABLA IDIOMA SI SE SELECCIONA -->
                <table border='1px' id="tablaIdiomas">
                    <thead>
                        <tr>
                            <th>A1</th>
                            <th>A2</th>
                            <th>B1</th>
                            <th>B2</th>
                            <th>C1</th>
                            <th>C2</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>
                                <input type="number" id="inputA1" name="inputA1" value="0" min="0">
                            </td>
                            <td>
                                <input type="number" id="inputA2" name="inputA2" value="0" min="0">
                            </td>
                            <td>
                                <input type="number" id="inputB1" name="inputB1" value="0" min="0">
                            </td>
                            <td>
                                <input type="number" id="inputB2" name="inputB2" value="0" min="0">
                            </td>
                            <td>
                                <input type="number" id="inputC1" name="inputC1" value="0" min="0">
                            </td>
                            <td>
                                <input type="number" id="inputC2" name="inputC2" value="0" min="0">
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <div id="submitContainer">
                    <button onclick="retroceder(event)">Retroceder</button>
                    <input type="submit" id="btnEnviar" value="Crear Convocatoria">
                </div>
            </div>
        </form>
    </div>
    <script src="js/crearConvocatoria.js"></script>
</body>