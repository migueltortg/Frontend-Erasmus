<!-- Vista Formulario Convocatoria -->
<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/listaSolicitud.css">
</head>
<body>
    
    <script src="js/listadoSolicitud.js"></script>
    <div id="botonesHeader">
        <button onclick="volver('landingPageCoordinador')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Listado de Solicitudes</h1>
        </div>
        <div id="contenido">
            <label for="grupoFiltro">Filtro Grupo:</label>
            <select name="grupoFiltro" id="grupoFiltro"> 
                <option value="CUALQUIERA">Cualquiera</option>
                <?php 
                    $conexion=DB::getConexion();
                    interfaceGrupo::cargarSelect($conexion);
                ?>
            </select>
            <table border="1px" id="solicitudTabla">
                <thead>
                    <tr>
                        <th>ID SOLICITUD</th>
                        <th>DNI CANDIDATO</th>
                        <th>ID CONVOCATORIA</th>
                        <th>GRUPO</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
</body>