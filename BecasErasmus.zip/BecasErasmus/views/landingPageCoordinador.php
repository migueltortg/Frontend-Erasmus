<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/landingPageCoordinador.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Menu de Coordinador</h1>
        </div>
        <div id="contenido">
            <button onclick="navegar('listaSolicitudes')">Corregir Solicitudes</button>
            <button onclick="navegar('crearConvocatoria')">Crear Convocatoria</button>
            <button onclick="navegar('crearProyecto')">Crear Proyecto</button>
            <button onclick="navegar('sacarListados')">Sacar Listados</button>
            <button onclick="navegar('eliminarConvocatoria')">Eliminar Convocatoria</button>
        </div>
    </div>
    <script src="js/landingPageCoordinador.js"></script>
</body>