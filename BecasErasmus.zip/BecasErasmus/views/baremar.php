<head>
    <title>Beca Erasmus</title>
    <link rel="stylesheet" href="css/baremar.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="volver('listaSolicitudes')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <?php 
                echo "<h2>Baremar Solicitud ".$_GET['idSolicitud']."</h2>";
            ?>
        </div>
        <div id="contenido">
            <form method="POST" action=""> 
                <?php 
                    $conexion=DB::getConexion();
                    $solicitud=databaseRep::solicitudID($conexion,$_GET['idSolicitud']);
                    $candidato=databaseRep::candidatoID($conexion,$solicitud->get_dni_candidato());

                    echo "
                        <input type='number' value='".$_GET['idSolicitud']."' id='idSolicitud'>
                        <label for='inputIdConvocatoria'>Convocatoria: </label>
                        <input type='number' value='".$solicitud->get_id_convocatoria()."' id='inputIdConvocatoria' readonly name='inputIdConvocatoria'>
                        <label for='inputDNI'>DNI del Candidato: </label>
                        <input type='text' value='".$solicitud->get_dni_candidato()."' readonly name='inputDNI'>
                        <label for='inputNombre'>Nombre del Candidato: </label>
                        <input type='text' value='".$candidato->get_nombre()."' readonly name='inputNombre'>
                        <label for='inputAP1'>Primer Apellido del Candidato: </label>
                        <input type='text' value='".$candidato->get_ap1()."' readonly name='inputAP1'>
                        <label for='inputAP2'>Segundo Apellido del Candidato: </label>
                        <input type='text' value='".$candidato->get_ap2()."' readonly name='inputAP2'>
                    ";

                    $convocatoria_item=databaseRep::item_convocatoriaID($conexion,$solicitud->get_id_convocatoria());
                    echo "
                    <table border='1px' id='tablaItems'>
                        <thead>
                            <tr>
                                <th>ID_ITEM</th>
                                <th>OBLIGATORIO</th>
                                <th>VALOR MINIMO</th>
                                <th>VALOR MAXIMO</th>
                                <th>Archivo</th>
                                <th>Nota</th>
                            </tr>
                        </thead>
                        <tbody>
                    ";
                    foreach($convocatoria_item as $item){
                        $recurso="";
                        if($item->get_presentaUser()==1){
                            $ruta="";
                            switch($item->get_id_item()){
                                case "1":
                                    $recurso="
                                    <select>
                                        ".interfaceItem::cargarSelectIdioma($conexion)."
                                    </select>
                                    ";
                                    break;
                                case "3":
                                    $ruta="certificadosNotas/";
                                    $ruta=$ruta.$item->get_id_convocatoria().$candidato->get_dni().".pdf";
                                    $recurso="<button onclick=verPDFsrc(event,'".$ruta."')>Ver Documento</button>";
                                    break;
                                case "4":
                                    $ruta="certificadosIdoneidad/";
                                    $ruta=$ruta.$item->get_id_convocatoria().$candidato->get_dni().".pdf";
                                    $recurso="<button onclick=verPDFsrc(event,'".$ruta."')>Ver Documento</button>";
                                    break;
                            }
                        }
                        $obligatorio="NO";
                        if($item->get_obligatorio()==1){
                            $obligatorio="SI";
                        }
                        $disableIdioma="";
                        if($item->get_id_item()==1){
                            $disableIdioma="readonly id='inputIdioma'";
                        }
                        $nota=databaseRep::notaBaremacion($conexion,$_GET['idSolicitud'],$item->get_id_item());

                        echo "
                            <tr id='".$item->get_id_item()."'>
                                <td>".$item->get_id_item()."</td>
                                <td>".$obligatorio."</td>
                                <td>".$item->get_valor_min()."</td>
                                <td>".$item->get_valor_max()."</td>
                                <td>".$recurso."</td>
                                <td><input type='number' value='".$nota."' max='".$item->get_valor_max()."' min='".$item->get_valor_min()."' name='inputNota' ".$disableIdioma."></td>
                            </tr>
                        ";//EL VALOR DE LA NOTA SE REVISARA EN BAREMACION
                    }
                    echo "
                        </tbody>
                    </table>
                    ";
                ?>
                <input type="submit" value="Corregir" id="btnBaremar">
            </form>
        </div>
    </div>
    <script src="js/baremar.js"></script>
    <script src="js/verPDF.js"></script>
</body>