<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/sacarListados.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="volver('landingPageCoordinador')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Sacar Listas Definitivas</h1>
        </div>
        <div id="contenido">
            <label for="grupoFiltro">Filtro Grupo:</label>
            <select name="grupoFiltro" id="grupoFiltro"> 
                <option value="CUALQUIERA">Cualquiera</option>
                <?php 
                    $conexion=DB::getConexion();
                    interfaceGrupo::cargarSelect($conexion);
                ?>
            </select>
            <table border="1px" id="convocatoriaTabla">
                <thead>
                    <tr>
                        <th>ID_CONVOCATORIA</th>
                        <th>N_MOVILIDADES</th>
                        <th>TIPO</th>
                        <th>PAIS</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <script src="js/sacarListados.js"></script>
</body>