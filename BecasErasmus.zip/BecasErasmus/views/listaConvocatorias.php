<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/listaConvocatorias.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Listado de Convocatorias</h1>
        </div>
        <div id="contenido">
            <label for="grupoFiltro">Filtro Grupo:</label>
            <select name="grupoFiltro" id="grupoFiltro"> 
                <option value="CUALQUIERA">Cualquiera</option>
                <?php 
                    $conexion=DB::getConexion();
                    interfaceGrupo::cargarSelect($conexion);
                ?>
            </select>
            <table border="1px" id="convocatoriaTabla">
                <thead>
                    <tr>
                        <th>ID_CONVOCATORIA</th>
                        <th>N_MOVILIDADES</th>
                        <th>TIPO</th>
                        <th>PAIS</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <script src="js/listadoConvocatoria.js"></script>
</body>