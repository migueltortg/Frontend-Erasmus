<?php
    loginRep::inicioSesion();

    $conexion=DB::getConexion();
    switch (databaseRep::rolDNI($conexion,$_SESSION['user']->get_dni())) {
        case "coordinador":
            //ENRUTAR PANTALLAS COORDINADOR
            if($_GET['vista']=="baremar"){
                require_once "baremar.php";
            }else if($_GET['vista']=="crearProyecto"){
                require_once "crearProyecto.php";
            }else if($_GET['vista']=="crearConvocatoria"){
                require_once "crearConvocatoria.php";
            }else if($_GET['vista']=="listaSolicitudes"){
                require_once "listaSolicitudes.php";
            }else if($_GET['vista']=="sacarListados"){
                require_once "sacarListados.php";
            }else if($_GET['vista']=="eliminarConvocatoria"){
                require_once "eliminarConvocatoria.php";
            }else{
                require_once "landingPageCoordinador.php";
            }
            break;
        case "user":
            if($_GET['vista']=="verConvocatoria"){
                require_once "verConvocatoria.php";
            }else if($_GET['vista']=="crearSolicitud"){
                require_once "crearSolicitud.php";
            }else{
                require_once "listaConvocatorias.php";
            }
            break;
    }
?>