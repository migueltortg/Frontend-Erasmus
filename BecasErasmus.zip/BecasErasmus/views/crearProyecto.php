<!-- Vista Formulario Convocatoria -->
<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/crearProyecto.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="volver('landingPageCoordinador')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Crear Proyecto</h1>
        </div>
        <form action="api/crearProyecto.php" method="POST">
            <label for="nombreProyecto">Nombre del Proyecto:</label>
            <input type="text" name="nombreProyecto" required>
            <label for="fecha_inicio">Fecha Inicio:</label>
            <input type="datetime-local" name="fecha_inicio" required>
            <label for="fecha_fin">Fecha Fin:</label>
            <input type="datetime-local" name="fecha_fin" required>
            <input type="submit" value="Crear Proyecto" id="btnSubmit">
        </form>
    </div>
    <script src="js/crearProyecto.js"></script>
</body>