<?php
    if (isset($_GET['vista'])) {
        loginRep::inicioSesion();
        
        //loginRep::destruirSession();
        if(loginRep::estaLogueado()){
            require_once "enrutaPantallas.php";
        }else if ($_GET['vista'] == "registro"){
            require_once "registro.php";
        }else{
            require_once "login.php";
        }
    }
?>