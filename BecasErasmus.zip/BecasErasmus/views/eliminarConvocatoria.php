<!-- Vista Formulario Convocatoria -->
<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/eliminarConvocatoria.css">
</head>
<body>
    <script src="js/borrarConvocatoria.js"></script>
    <div id="botonesHeader">
        <button onclick="volver('landingPageCoordinador')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Eliminar Convocatoria</h1>
        </div>
        <div id="contenido">
            <?php 
                $conexion=DB::getConexion();
                echo interfaceConvocatoria::cargarTabla($conexion);
            ?>
        </div>
    </div>
</body>