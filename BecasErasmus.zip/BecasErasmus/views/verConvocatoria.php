<head>
    <title>Beca Erasmus</title>
    <link rel="stylesheet" href="css/verConvocatoria.css">
</head>
<body>
            
    <div id="botonesHeader">
        <button onclick="volver('listaConvocatoria')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <?php 
                echo "<h2>Convocatoria ".$_GET['idConvocatoria']."</h2>";
            ?>
        </div>

        <div id="contenido">
            <?php 
                $convocatoria=databaseRep::devolverConvocatoria(DB::getConexion(),$_GET['idConvocatoria']);
                echo "
                    <label for='numMovilidades'>Numero de Movilidades: </label>
                    <input type='number' value='".$convocatoria->get_n_movilidades()."' disabled>
                    <label for='tipo'>Tipo Movilidad: </label>
                    <input type='text' value='".$convocatoria->get_tipo()."' disabled>
                    <h3>Fechas: </h3>
                    <ul>
                        <li>
                            <h5>Fecha Solicitudes: </h5>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_inicio_solicitudes()."'  class='fecha'>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_fin_solicitudes()."'  class='fecha'>
                        </li>
                        <li>
                            <h5>Fecha Pruebas Seleccion: </h5>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_inicio_pruebas_seleccion()."'  class='fecha'>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_fin_pruebas_seleccion()."'  class='fecha'>                
                        </li>
                        <li>
                            <h5>Fecha Listas Definitivas: </h5>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_inicio_listas_definitivas()."' class='fecha'>
                            <input type='datetime-local' disabled value='".$convocatoria->get_f_fin_listas_definitivas()."'  class='fecha'>                 
                        </li>
                    </ul>
                    <label for='pais'>Pais:</label>
                    <input type='text' disabled value='".$convocatoria->get_pais()."'>
                    <label>Codigo Proyecto: </label>
                    <input type='number' disabled value='".$convocatoria->get_proyecto_cod()."'>
                    <button id='btnSolicitar' onclick='solicitarConvocatoria(event,".$_GET['idConvocatoria'].")'>Solicitar</button>
                ";

            ?>
            <script src="js/verConvocatoria.js"></script>
        </div>
    </div>
</body>