<head>
    <title>Registro</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="css/registro.css">
</head>
<body>
    <div id="container">
        <form action="" method="post"> 
            <div id="parteCandidato">
                <h1>Registro Candidato</h1>
                <div>
                    <h3>DNI</h3>
                    <input type="text" name="dni" id="inputDni">
                </div>
                <div>
                    <h3>Contraseña</h3>
                    <input type="text" name="contraseña" id="inputContraseña">
                </div>
                <div>
                    <h3>Nombre</h3>
                    <input type="text" name="nombre" id="inputNombre">
                </div>
                <div>
                    <h3>Primer Apellido</h3>
                    <input type="text" name="primerApellido" id="inputAp1">
                </div>
                <div>
                    <h3>Segundo Apellido</h3>
                    <input type="text" name="segundoApellido" id="inputAp2">
                </div>
                <div>
                    <h3>Fecha Nacimiento</h3>
                    <input type="date" name="fecha_nac" id="inputFecha_Nac">
                </div>
                <div>
                    <h3>Grupo</h3><!-- AQUI UN SELECT QUE SE CARGARA CON LOS DISTINTOS GRUPOS -->
                    <select name="grupoSelect">
                        <?php 
                            $conexion=DB::getConexion();
                            interfaceGrupo::cargarSelect($conexion);
                        ?>
                    </select>
                </div>
                <div>
                    <h3>Teléfono</h3>
                    <input type="text" name="tfno" id="inputTfno">
                </div>
                <div>
                    <h3>Email</h3>
                    <input type="text" name="email" id="inputEmail">
                </div>
                <div>
                    <h3>Domicilio</h3>
                    <input type="text" name="domicilio" id="inputDomicilio">
                </div>
                <input type="button" value="Siguiente" name="registroSiguiente" id="buttonSiguiente" class="boton">
            </div>  
            <div id="parteTutor"><!-- Cambiar id -->
                <h1>Registro Tutor</h1>
                <div>
                    <h3>DNI</h3>
                    <input type="text" name="dniTutor" id="inputDniTutor">
                </div>
                <div>
                    <h3>Nombre</h3>
                    <input type="text" name="nombreTutor" id="inputNombreTutor">
                </div>
                <div>
                    <h3>Primer Apellido</h3>
                    <input type="text" name="ap1Tutor" id="inputAP1Tutor">
                </div>
                <div>
                    <h3>Segundo Apellido</h3>
                    <input type="text" name="ap2Tutor" id="inputAP2Tutor">
                </div>
                <div>
                    <h3>Teléfono</h3>
                    <input type="text" name="tfnoTutor" id="inputTFNOTutor">
                </div>
                <div>
                    <h3>Email</h3>
                    <input type="text" name="emailTutor" id="inputEmailTutor">
                </div>
                <div>
                    <input type="button" value="Anterior" name="registroAnterior" id="buttonAnterior" class="boton">
                    <input type="submit" value="Enviar" name="registroSubmit" id="registroSubmit" class="boton">
                </div>
            </div>     
        </form>
    </div>
    <script src="js/registro.js"></script>
</body>