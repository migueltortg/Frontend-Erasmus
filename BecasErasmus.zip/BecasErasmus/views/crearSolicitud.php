<!-- Vista Formulario Convocatoria -->
<head>
    <title>Becas Erasmus</title>
    <link rel="stylesheet" href="css/crearSolicitud.css">
</head>
<body>
    <div id="botonesHeader">
        <button onclick="volver('verConvocatoria')">Volver</button>
        <button onclick="cerrarSesion()">Cerrar Sesión</button>
    </div>
    <div>
        <div id="titulo">
            <h1>Crear Solicitud</h1>
        </div>
        <form action="" method="POST" id="formSolicitud">
            <div id="parteCandidato">
                <label for="idConvocatoria">Convocatoria: </label>
                <?php 
                    echo "
                        <input type='number' name='idConvocatoria' id='inputID'value='".$_GET['idConvocatoria']."'>
                    ";
                ?>
                <label for="dni">DNI: </label>
                <input type="text" name="dni">
                <label for="nombre">Nombre: </label>
                <input type="text" name="nombre">
                <label for="ap1">Primer Apellido: </label>
                <input type="text" name="ap1">
                <label for="ap2">Segundo Apellido: </label>
                <input type="text" name="ap2">
                <label for="grupo">Grupo: </label>
                <select name="grupo">
                    <?php 
                        $conexion=DB::getConexion();
                        interfaceGrupo::cargarSelect($conexion);
                    ?>
                </select>
                <label for="tfno">Teléfono: </label>
                <input type="text" name="tfno">
                <label for="email">Email: </label>
                <input type="text" name="email">
                <label for="domicilio">Domicilio: </label>
                <input type="text" name="domicilio">

                <button onclick="siguiente(event)" id="btnSiguiente">Siguiente</button>
            </div>
            <div id="parteItems">
                <?php 
                    $conexion=DB::getConexion();
                    interfaceItem::cargarForm($conexion,$_GET['idConvocatoria']);
                ?>
                <img id='imgFotoPerfil'>
                <button id="boton" onclick="modalFoto(event)">Sacarse foto</button>
                <input type="hidden" id="blob" name="blob">
                <button onclick="anterior(event)" id="btnAnterior">Anterior</button>
                <input type='submit' name='inputSubmit' id='inputSubmit'>
            </div>
        </form>
    </div>
    <script src="js/crearSolicitud.js"></script>
    <script src="js/webcam.js"></script>
    <script src="js/verPDF.js"></script>
</body>