<?php
class Principal
{
    public static function main()
    {
        require_once "helper/autocargador.php";
        require_once 'views/enrutador.php';
    }
}
Principal::main();
?>