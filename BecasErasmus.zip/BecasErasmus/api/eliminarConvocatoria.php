<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();

    databaseRep::eliminarConvocatoria($conexion,$_POST['id']);
?>