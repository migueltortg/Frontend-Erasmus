<?php 
    require_once "../helper/autocargador.php";

    loginRep::inicioSesion();

    echo json_encode($_SESSION['user']);
?>