<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();
    
    if($_POST['dniTutor']==null){
        $candidato=candidatoRep::crearCandidato($_POST['dni'],$_POST['contraseña'],$_POST['fecha_nac'],$_POST['nombre'],$_POST['ap1'],$_POST['ap2'],$_POST['grupo'],$_POST['tfno']
        ,$_POST['email'],$_POST['domicilio'],"");
    }else{
        $tutor=tutorRep::crearTutor($_POST['dniTutor'],$_POST['nombreTutor'],$_POST['ap1Tutor'],$_POST['ap2Tutor'],$_POST['tfnoTutor'],$_POST['emailTutor']);
        databaseRep::introducirTutor($conexion,$tutor);

        $candidato=candidatoRep::crearCandidato($_POST['dni'],$_POST['contraseña'],$_POST['fecha_nac'],$_POST['nombre'],$_POST['ap1'],$_POST['ap2'],$_POST['grupo'],$_POST['tfno']
        ,$_POST['email'],$_POST['domicilio'],$tutor->get_dni_tutor());
    }
    
    databaseRep::introducirCandidato($conexion,$candidato);
?>