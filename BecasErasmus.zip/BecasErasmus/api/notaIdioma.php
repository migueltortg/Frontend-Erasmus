<?php
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();
    echo databaseRep::valorIdioma($conexion,$_POST['titulo'],$_POST['idConvocatoria']);
?>