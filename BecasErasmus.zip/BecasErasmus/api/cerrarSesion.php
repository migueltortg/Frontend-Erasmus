<?php 
    require_once "../helper/autocargador.php";

    loginRep::inicioSesion();
    loginRep::destruirSession();
?>