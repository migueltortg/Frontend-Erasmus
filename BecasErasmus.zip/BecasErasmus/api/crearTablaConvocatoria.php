<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();

    $convocatorias="HOLA";
    if($_POST['tipo']=="CUALQUIERA"){
        $convocatorias=databaseRep::selectUniversal($conexion,"CONVOCATORIA");
    }else{
        $convocatorias=databaseRep::convocatoriaTipo($conexion,$_POST['tipo']);
    }

    echo json_encode($convocatorias);
?>