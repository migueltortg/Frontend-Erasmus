<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();
    
    $proyecto=proyectoRep::crearProyecto("",$_POST['nombreProyecto'],$_POST['fecha_inicio'],$_POST['fecha_fin']);
    
    databaseRep::introducirProyecto($conexion,$proyecto);

    header("Location: http://localhost/BECASERASMUS/index.php?vista=landingPageCoordinador");

?>