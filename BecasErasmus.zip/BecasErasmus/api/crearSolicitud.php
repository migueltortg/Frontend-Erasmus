<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();
    loginRep::inicioSesion();

    $solicitud=solicitudRep::crearSolicitud("",$_SESSION['user']->get_dni(),$_POST['idConvocatoria'],$_POST['grupo']
    ,$_POST['tfno'],$_POST['email'],$_POST['domicilio'],$_POST['fotoPerfil']);

    databaseRep::introducirSolicitud($conexion,$solicitud);

    $idSolicitud=databaseRep::idUltSolicitud($conexion,$solicitud->get_email());

    $arrayItem=databaseRep::item_convocatoria($conexion,$_POST['idConvocatoria']);
    
    foreach($arrayItem as $item){
        switch($item->ID_ITEM){
            case "1":
                //inputIdioma
                $file_extension = pathinfo($_FILES['inputIdioma']['name'], PATHINFO_EXTENSION);
                $ruta="../certificadosIdioma/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";
                move_uploaded_file($_FILES['inputIdioma']['tmp_name'], $ruta);
                $ruta="certificadosIdioma/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";

                $baremacion=baremacionRep::crearBaremacion("",$item->ID_ITEM,$idSolicitud,null,$ruta);
                databaseRep::introducirBaremacion($conexion,$baremacion);
                break;
            case "2":
                $baremacion=baremacionRep::crearBaremacion("",$item->ID_ITEM,$idSolicitud,null,null);
                databaseRep::introducirBaremacion($conexion,$baremacion);
                break;
            case "3":
                //inputNotas
                $file_extension = pathinfo($_FILES['inputNotas']['name'], PATHINFO_EXTENSION);
                $ruta="../certificadosNotas/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";
                move_uploaded_file($_FILES['inputNotas']['tmp_name'], $ruta);
                $ruta="certificadosNotas/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";

                $baremacion=baremacionRep::crearBaremacion("",$item->ID_ITEM,$idSolicitud,null,$ruta);
                databaseRep::introducirBaremacion($conexion,$baremacion);
                break;
            case "4":
                //inputIdoneidad
                $file_extension = pathinfo($_FILES['inputIdoneidad']['name'], PATHINFO_EXTENSION);
                $ruta="../certificadosIdoneidad/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";
                move_uploaded_file($_FILES['inputIdoneidad']['tmp_name'], $ruta);
                $ruta="certificadosIdoneidad/".$_POST['idConvocatoria'].$_SESSION['user']->get_dni().".pdf";

                $baremacion=baremacionRep::crearBaremacion("",$item->ID_ITEM,$idSolicitud,null,$ruta);
                databaseRep::introducirBaremacion($conexion,$baremacion);
                break;
        }
    }
?>