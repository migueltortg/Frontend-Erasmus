<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();

    $solicitudes="";
    if($_POST['tipo']=="CUALQUIERA"){
        $solicitudes=databaseRep::selectUniversal($conexion,"SOLICITUD");
    }else{
        $solicitudes=databaseRep::solicitudTipo($conexion,$_POST['tipo']);
    }

    echo json_encode($solicitudes);
?>