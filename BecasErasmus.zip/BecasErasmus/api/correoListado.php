<?php 
    require_once "../helper/autocargador.php";
    require '../vendor/autoload.php';

    $conexion=DB::getConexion();
    $convocatoria=databaseRep::devolverConvocatoria($conexion,$_POST['id']);

    $filasAdmitidos=interfaceCandidatos::filasAdmitidos($conexion,$_POST['id']);
    $filasReservas=interfaceCandidatos::filasReservas($conexion,$_POST['id']);

    $htmlTable = "
        <h1>Lista definitiva CONVOCATORIA " .$convocatoria->get_id_convocatoria(). "</h1>
        <h3>Admitidos</h3>
        <table border='1px'>
            <tr>
                <th>Puesto</th>
                <th>DNI</th>
                <th>Nombre</th>
                <th>Nota</th>
            </tr>
            ".$filasAdmitidos."
        </table> 
        <h3>Reservas</h3>
        <table border='1px'>
            <tr>
                <th>Puesto</th>
                <th>DNI</th>
                <th>Nombre</th>
                <th>Nota</th>
            </tr>
            ".$filasReservas."
        </table>
    ";

    use Dompdf\Dompdf;
    use Dompdf\Options;

    $options = new Options();
    $options->set('isHtml5ParserEnabled', true);
    $options->set('isPhpEnabled', true);

    $dompdf = new Dompdf($options);
    $dompdf->loadHtml($htmlTable);
    $dompdf->setPaper('A4', 'portrait');
    $dompdf->render();

    $pdfContent = $dompdf->output();


    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

    $mail = new PHPMailer(true);

    try {
        $mail->isSMTP();
        $mail->SMTPDebug  = 2;                          
        $mail->SMTPAuth   = true;
        $mail->SMTPSecure = "tls";                 
        $mail->Host       = "smtp.gmail.com";    
        $mail->Port       = 587;           

        $mail->Username   = "migueltortg@gmail.com";

        $mail->Password   = "uyzs erbk ildm mrmj";

        $mail->setFrom('migueltortg@gmail.com', 'Miguel Ángel');
        $mail->addAddress('migueltortg@gmail.com');
        $mail->addStringAttachment($pdfContent, 'table.pdf', 'base64', 'application/pdf');
        
        $mail->isHTML(true);
        $mail->Subject = 'Lista de Admitidos';
        $mail->Body    = 'A continuación podras acceder al archivo donde salen los candidatos seleccionados y reservas.';
        
        $mail->send();
        echo 'Correo electrónico enviado con éxito.';
    } catch (Exception $e) {
        echo "Error al enviar el correo electrónico: {$mail->ErrorInfo}";
    }
?>