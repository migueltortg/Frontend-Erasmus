<?php 
    require_once "../helper/autocargador.php";

    $conexion=DB::getConexion();

    for($i=1;$i<=3;$i++){
        if(isset($_POST['inputItem'.$i])){
            databaseRep::modificarNota($conexion,$_POST['idSolicitud'],$i,$_POST['inputItem'.$i]);
        }
    }
?>