<?php 
    require_once "../helper/autocargador.php";
    
    $conexion=DB::getConexion();

    $validacion=new Validacion();

    $convocatoria=convocatoriaRep::crearConvocatoria("",$_POST['NumMovilidades'],$_POST['TipoMovilidad']
    ,$_POST['f_inicio_solicitudes'],$_POST['f_fin_solicitudes'],$_POST['f_inicio_pruebas'],
    $_POST['f_fin_pruebas'],$_POST['f_inicio_listas'],$_POST['f_fin_listas'],$_POST['pais'],$_POST['proyecto']);

    databaseRep::introducirConvocatoria($conexion,$convocatoria);
    
    //ID DE LA CONVOCATORIA QUE ACABAMOS DE INTRODUCIR
    $idConvocatoria=databaseRep::idUltConvocatoria($conexion);

    $grupos=databaseRep::selectUniversal($conexion,"GRUPO");
    
    foreach($grupos as $grupo){
        if(isset($_POST[$grupo->CLAVE])){
            databaseRep::introducirGrupo_Convocatoria($conexion,$idConvocatoria,$grupo->CLAVE);
        }
    }

    if(isset($_POST['valor_max1'])){
        $idioma_itemA1=idioma_item_baremableRep::crearIdioma_item_baremable("", "1", $idConvocatoria, $_POST['inputA1']);
        $idioma_itemA2=idioma_item_baremableRep::crearIdioma_item_baremable("", "2", $idConvocatoria, $_POST['inputA2']);
        $idioma_itemB1=idioma_item_baremableRep::crearIdioma_item_baremable("", "3", $idConvocatoria, $_POST['inputB1']);
        $idioma_itemB2=idioma_item_baremableRep::crearIdioma_item_baremable("", "4", $idConvocatoria, $_POST['inputB2']);
        $idioma_itemC1=idioma_item_baremableRep::crearIdioma_item_baremable("", "5", $idConvocatoria, $_POST['inputC1']);
        $idioma_itemC2=idioma_item_baremableRep::crearIdioma_item_baremable("", "6", $idConvocatoria, $_POST['inputC2']);

        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemA1);
        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemA2);
        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemB1);
        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemB2);
        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemC1);
        databaseRep::introducirIdioma_item_baremable($conexion,$idioma_itemC2);
    }

    $arrayItem=array();
    for($i=1;$i<5;$i++){
        if(isset($_POST["valor_max".$i])){
            $item_baremable=item_convocatoriaRep::crearItem_Convocatoria("",$idConvocatoria,$i,$_POST["obligatorio".$i],$_POST["presentaUser".$i],$_POST["valor_min".$i],
            $_POST["valor_max".$i]);
            array_push($arrayItem,$item_baremable);
        }
    }

    databaseRep::introducirItemConvocatoria($conexion,$arrayItem); 

    header("Location: http://localhost/BECASERASMUS/index.php?vista=landingPageCoordinador");
    
?>