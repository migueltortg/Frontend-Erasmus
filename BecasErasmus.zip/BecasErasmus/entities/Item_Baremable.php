<?php 
    class Item_Baremable{
        private $id_item_baremable;
        private $nombre;

        public function __construct($id_item_baremable,$nombre){
            $this->id_item_baremable=$id_item_baremable;
            $this->nombre=$nombre;
        }

        //GETTERS
        public function get_id_item_baremable(){
            return $this->id_item_baremable;
        }

        public function get_nombre(){
            return $this->nombre;
        }

        //SETTERS
        public function set_nombre($nombre){
            $this->nombre = $nombre;
        }
    }
?>