<?php

class Idioma_Baremo_Convocatoria {
    private $idIdiomaBaremo;
    private $idIdioma;
    private $idConvocatoria;
    private $nota;

    // Constructor
    public function __construct($idIdiomaBaremo, $idIdioma, $idConvocatoria, $nota) {
        $this->idIdiomaBaremo = $idIdiomaBaremo;
        $this->idIdioma = $idIdioma;
        $this->idConvocatoria = $idConvocatoria;
        $this->nota = $nota;
    }

    // Getters
    public function getIdIdiomaBaremo() {
        return $this->idIdiomaBaremo;
    }

    public function getIdIdioma() {
        return $this->idIdioma;
    }

    public function getIdConvocatoria() {
        return $this->idConvocatoria;
    }

    public function getNota() {
        return $this->nota;
    }

    // Setters
    public function setIdIdioma($idIdioma) {
        $this->idIdioma = $idIdioma;
    }

    public function setIdConvocatoria($idConvocatoria) {
        $this->idConvocatoria = $idConvocatoria;
    }

    public function setNota($nota) {
        $this->nota = $nota;
    }
}

?>