<?php 
    class Convocatoria implements JsonSerializable{
        private $id_convocatoria;
        private $n_movilidades;
        private $tipo;
        private $f_inicio_solicitudes;
        private $f_fin_solicitudes;
        private $f_inicio_pruebas_seleccion;
        private $f_fin_pruebas_seleccion;
        private $f_inicio_listas_definitivas;
        private $f_fin_listas_definitivas;
        private $pais;
        private $proyecto_cod;

        public function __construct($id_convocatoria,$n_movilidades,$tipo,$f_inicio_solicitudes,$f_fin_solicitudes
        ,$f_inicio_pruebas_seleccion,$f_fin_pruebas_seleccion,$f_inicio_listas_definitivas,$f_fin_listas_definitivas,$pais,$proyecto_cod){
            $this->id_convocatoria=$id_convocatoria;
            $this->n_movilidades=$n_movilidades;
            $this->tipo=$tipo;
            $this->f_inicio_solicitudes=$f_inicio_solicitudes;
            $this->f_fin_solicitudes=$f_fin_solicitudes;
            $this->f_inicio_pruebas_seleccion=$f_inicio_pruebas_seleccion;
            $this->f_fin_pruebas_seleccion=$f_fin_pruebas_seleccion;
            $this->f_inicio_listas_definitivas=$f_inicio_listas_definitivas;
            $this->f_fin_listas_definitivas=$f_fin_listas_definitivas;
            $this->pais=$pais;
            $this->proyecto_cod=$proyecto_cod;
        }

        //GETTERS
        public function get_id_convocatoria(){
            return $this->id_convocatoria;
        }

        public function get_n_movilidades(){
            return $this->n_movilidades;
        }

        public function get_tipo(){
            return $this->tipo;
        }

        public function get_f_inicio_solicitudes(){
            return $this->f_inicio_solicitudes;
        }

        public function get_f_fin_solicitudes(){
            return $this->f_fin_solicitudes;
        }

        public function get_f_inicio_pruebas_seleccion(){
            return $this->f_inicio_pruebas_seleccion;
        }

        public function get_f_fin_pruebas_seleccion(){
            return $this->f_fin_pruebas_seleccion;
        }

        public function get_f_inicio_listas_definitivas(){
            return $this->f_inicio_listas_definitivas;
        }

        public function get_f_fin_listas_definitivas(){
            return $this->f_fin_listas_definitivas;
        }

        public function get_pais(){
            return $this->pais;
        }

        public function get_proyecto_cod(){
            return $this->proyecto_cod;
        }

        //SETTERS
        public function set_n_movilidades($n_movilidades){
            $this->n_movilidades = $n_movilidades;
        }

        public function set_tipo($tipo){
            $this->tipo = $tipo;
        }

        public function set_f_inicio_solicitudes($f_inicio_solicitudes){
            $this->f_inicio_solicitudes = $f_inicio_solicitudes;
        }

        public function set_f_fin_solicitudes($f_fin_solicitudes){
            $this->f_fin_solicitudes = $f_fin_solicitudes;
        }

        public function set_f_inicio_pruebas_seleccion($f_inicio_pruebas_seleccion){
            $this->f_inicio_pruebas_seleccion = $f_inicio_pruebas_seleccion;
        }

        public function set_f_fin_pruebas_seleccion($f_fin_pruebas_seleccion){
            $this->f_fin_pruebas_seleccion = $f_fin_pruebas_seleccion;
        }

        public function set_f_inicio_listas_definitivas($f_inicio_listas_definitivas){
            $this->f_inicio_listas_definitivas = $f_inicio_listas_definitivas;
        }

        public function set_f_fin_listas_definitivas($f_fin_listas_definitivas){
            $this->f_fin_listas_definitivas = $f_fin_listas_definitivas;
        }

        public function set_pais($pais){
            $this->pais = $pais;
        }

        public function set_proyecto_cod($proyecto_cod){
            $this->proyecto_cod = $proyecto_cod;
        }

        public function jsonSerialize(){
            $vars = get_object_vars($this);
            return $vars;
        }
    }
?>