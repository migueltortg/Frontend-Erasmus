<?php 
    class Tutor{
        private $dni_tutor;
        private $nombre;
        private $ap1;
        private $ap2;
        private $tfno;
        private $domicilio;

        public function __construct($dni_tutor,$nombre,$ap1,$ap2,$tfno,$domicilio){
            $this->dni_tutor=$dni_tutor;
            $this->nombre=$nombre;
            $this->ap1=$ap1;
            $this->ap2=$ap2;
            $this->tfno=$tfno;
            $this->domicilio=$domicilio;
        }

        //GETTERS
        public function get_dni_tutor(){
            return $this->dni_tutor;
        }

        public function get_nombre(){
            return $this->nombre;
        }

        public function get_ap1(){
            return $this->ap1;
        }

        public function get_ap2(){
            return $this->ap2;
        }

        public function get_tfno(){
            return $this->tfno;
        }

        public function get_domicilio(){
            return $this->domicilio;
        }

        //SETTERS
        public function set_tfno($tfno){
            $this->tfno = $tfno;
        }

        public function set_domicilio($domicilio){
            $this->domicilio = $domicilio;
        }
    }
?>