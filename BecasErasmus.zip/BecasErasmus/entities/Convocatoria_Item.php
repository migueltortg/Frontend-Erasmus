<?php 
    class Convocatoria_Item{
        private $id_convocatoria_item;
        private $id_convocatoria;
        private $id_item;
        private $obligatorio;
        private $presentaUser;
        private $valor_min;
        private $valor_max;

        public function __construct($id_convocatoria_item,$id_convocatoria,$id_item,$obligatorio,$presentaUser,$valor_min,$valor_max){
            $this->id_convocatoria_item=$id_convocatoria_item;
            $this->id_convocatoria=$id_convocatoria;
            $this->id_item=$id_item;
            $this->obligatorio=$obligatorio;
            $this->presentaUser=$presentaUser;
            $this->valor_min=$valor_min;
            $this->valor_max=$valor_max;
        }

        //GETTERS
        public function get_id_convocatoria_item(){
            return $this->id_convocatoria_item;
        }

        public function get_id_convocatoria(){
            return $this->id_convocatoria;
        }

        public function get_id_item(){
            return $this->id_item;
        }

        public function get_obligatorio(){
            return $this->obligatorio;
        }

        public function get_presentaUser(){
            return $this->presentaUser;
        }

        public function get_valor_min(){
            return $this->valor_min;
        }

        public function get_valor_max(){
            return $this->valor_max;
        }

        //SETTERS
        public function set_id_convocatoria($id_convocatoria){
            $this->id_convocatoria = $id_convocatoria;
        }

        public function set_id_item($id_item){
            $this->id_item = $id_item;
        }

        public function set_obligatorio($obligatorio){
            $this->obligatorio = $obligatorio;
        }

        public function set_presentaUser($presentaUser){
            $this->presentaUser = $presentaUser;
        }

        public function set_valor_min($valor_min){
            $this->valor_min = $valor_min;
        }

        public function set_valor_max($valor_max){
            $this->valor_max = $valor_max;
        }
    }
?>