<?php 
    class Idioma{
        private $id_idioma;
        private $valor;

        public function __construct($id_idioma,$valor){
            $this->id_idioma=$id_idioma;
            $this->valor=$valor;
        }

        //GETTERS
        public function get_id_idioma(){
            return $this->id_idioma;
        }

        public function get_valor(){
            return $this->valor;
        }

        //SETTERS
        public function set_valor($valor){
            $this->valor = $valor;
        }
    }
?>