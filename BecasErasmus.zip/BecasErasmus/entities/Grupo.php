<?php 
    class Grupo{
        private $clave;
        private $nombre;

        public function __construct($clave,$nombre){
            $this->clave=$clave;
            $this->nombre=$nombre;
        }

        //GETTERS
        public function get_clave(){
            return $this->clave;
        }

        public function get_nombre(){
            return $this->nombre;
        }

        //SETTERS
        public function set_clave($clave){
            $this->clave = $clave;
        }

        public function set_nombre($nombre){
            $this->nombre = $nombre;
        }
    }
?>