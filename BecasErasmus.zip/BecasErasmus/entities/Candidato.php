<?php 
    class Candidato implements JsonSerializable{
        private $dni;
        private $password;
        private $fecha_nac;
        private $nombre;
        private $ap1;
        private $ap2;
        private $grupo;
        private $tfno;
        private $email;
        private $domicilio;
        private $dni_tutor;

        public function __construct($dni,$password,$fecha_nac,$nombre,$ap1,$ap2,$grupo,$tfno,$email,$domicilio,$dni_tutor){
            $this->dni=$dni;
            $this->password=$password;
            $this->fecha_nac=$fecha_nac;
            $this->nombre=$nombre;
            $this->ap1=$ap1;
            $this->ap2=$ap2;
            $this->grupo=$grupo;
            $this->tfno=$tfno;
            $this->email=$email;
            $this->domicilio=$domicilio;
            $this->dni_tutor=$dni_tutor;
        }

        //GETTERS
        public function get_dni(){
            return $this->dni;
        }

        public function get_password(){
            return $this->password;
        }

        public function get_fecha_nac(){
            return $this->fecha_nac;
        }

        public function get_nombre(){
            return $this->nombre;
        }

        public function get_ap1(){
            return $this->ap1;
        }

        public function get_ap2(){
            return $this->ap2;
        }

        public function get_grupo(){
            return $this->grupo;
        }

        public function get_tfno(){
            return $this->tfno;
        }

        public function get_email(){
            return $this->email;
        }

        public function get_domicilio(){
            return $this->domicilio;
        }

        public function get_dni_tutor(){
            return $this->dni_tutor;
        }

        //SETTERS
        public function set_password($password){
            $this->password = $password;
        }

        public function set_grupo($grupo){
            $this->grupo = $grupo;
        }

        public function set_tfno($tfno){
            $this->tfno = $tfno;
        }

        public function set_email($email){
            $this->email = $email;
        }

        public function set_domicilio($domicilio){
            $this->domicilio = $domicilio;
        }

        public function jsonSerialize(){
            $vars = get_object_vars($this);
            return $vars;
        }
    }
?>