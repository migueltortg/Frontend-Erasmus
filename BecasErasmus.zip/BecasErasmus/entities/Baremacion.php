<?php 
    class Baremacion{
        private $id_baremacion;
        private $id_item;
        private $id_solicitud;
        private $nota;
        private $url;

        public function __construct($id_baremacion,$id_item,$id_solicitud,$nota,$url){
            $this->id_baremacion=$id_baremacion;
            $this->id_item=$id_item;
            $this->id_solicitud=$id_solicitud;
            $this->nota=$nota;
            $this->url=$url;
        }

        //GETTERS
        public function get_id_baremacion(){
            return $this->id_baremacion;
        }

        public function get_id_item(){
            return $this->id_item;
        }

        public function get_id_solicitud(){
            return $this->id_solicitud;
        }

        public function get_nota(){
            return $this->nota;
        }

        public function get_url(){
            return $this->url;
        }

        //SETTERS
        public function set_id_item($id_item){
            $this->id_item = $id_item;
        }

        public function set_id_solicitud($id_solicitud){
            $this->id_solicitud = $id_solicitud;
        }

        public function set_nota($nota){
            $this->nota = $nota;
        }

        public function set_url($url){
            $this->url = $url;
        }
    }
?>