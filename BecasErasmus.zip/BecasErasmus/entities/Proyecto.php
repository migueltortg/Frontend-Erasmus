<?php 
    class Proyecto{
        private $cod_proyecto;
        private $nombre;
        private $proyecto_inicio;
        private $proyecto_fin;

        public function __construct($cod_proyecto,$nombre,$proyecto_inicio,$proyecto_fin){
            $this->cod_proyecto=$cod_proyecto;
            $this->nombre=$nombre;
            $this->proyecto_inicio=$proyecto_inicio;
            $this->proyecto_fin=$proyecto_fin;
        }

        //GETTERS
        public function get_cod_proyecto(){
            return $this->cod_proyecto;
        }

        public function get_nombre(){
            return $this->nombre;
        }

        public function get_proyecto_inicio(){
            return $this->proyecto_inicio;
        }

        public function get_proyecto_fin(){
            return $this->proyecto_fin;
        }

        //SETTERS
        public function set_nombre($nombre){
            $this->nombre = $nombre;
        }

        public function set_proyecto_inicio($proyecto_inicio){
            $this->proyecto_inicio = $proyecto_inicio;
        }

        public function set_proyecto_fin($proyecto_fin){
            $this->proyecto_fin = $proyecto_fin;
        }
    }
?>