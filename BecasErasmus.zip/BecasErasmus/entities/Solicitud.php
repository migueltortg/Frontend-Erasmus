<?php 
    class Solicitud implements JsonSerializable{
        private $id_solicitud;
        private $dni_candidato;
        private $id_convocatoria;
        private $grupo;
        private $tfno;
        private $email;
        private $domicilio;
        private $urlFoto;

        public function __construct($id_solicitud,$dni_candidato,$id_convocatoria,$grupo,$tfno,$email,$domicilio,$urlFoto){
            $this->id_solicitud=$id_solicitud;
            $this->dni_candidato=$dni_candidato;
            $this->id_convocatoria=$id_convocatoria;
            $this->grupo=$grupo;
            $this->tfno=$tfno;
            $this->email=$email;
            $this->domicilio=$domicilio;
            $this->urlFoto=$urlFoto;
        }

        //GETTERS
        public function get_id_solicitud(){
            return $this->id_solicitud;
        }

        public function get_dni_candidato(){
            return $this->dni_candidato;
        }

        public function get_id_convocatoria(){
            return $this->id_convocatoria;
        }

        public function get_grupo(){
            return $this->grupo;
        }

        public function get_tfno(){
            return $this->tfno;
        }

        public function get_email(){
            return $this->email;
        }

        public function get_domicilio(){
            return $this->domicilio;
        } 
        
        public function get_urlFoto(){
            return $this->urlFoto;
        }   

        public function jsonSerialize(){
            $vars = get_object_vars($this);
            return $vars;
        }
    }
?>