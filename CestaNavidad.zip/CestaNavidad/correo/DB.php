<?php 
    class DB {
        private static $conexion=null;
        
        public static function getConexion(){
            if(self::$conexion==null){
                self::$conexion=new PDO('mysql:host=datos;dbname=nombreDB', 'root', 'root');
            }
            return self::$conexion;
        }

        public static function desconectar(){
            self::$conexion=null;
        }
    }
?>