<?php   
    require "vendor/autoload.php";
    require "DB.php";
    use PHPMailer\PHPMailer\PHPMailer;
    use GuzzleHttp\Client;
    
    $cesta=false;
    
    $conexion=DB::getConexion();
    $resultado = $conexion->query("SELECT * FROM nombreDB.cesta where nombre='".$_POST['nombreInput']."';");
    
    while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
      $cesta=true;
      $email=$registro->email;
      $tipo=$registro->tipo;
    } 

    if($cesta==true){
      
      $mail = new PHPMailer();
      $mail->IsSMTP();
      // cambiar a 0 para no ver mensajes de error
      $mail->SMTPDebug  = 2;                          
      $mail->SMTPAuth   = true;
      $mail->SMTPSecure = "tls";                 
      $mail->Host       = "smtp.gmail.com";    
      $mail->Port       = 587;           

      $mail->Username   = "migueltortg@gmail.com"; //USUARIO QUE ENVIA

      $mail->Password   = "uyzs erbk ildm mrmj";    //CLAVE 
      $mail->SetFrom('migueltortg@gmail.com', 'Test');
      
      $mail->Subject    = "Hola Prueba";//ASUNTO

      $mail->MsgHTML($cesta);//TEXTO
      
      $address = "migueltortg@gmail.com";// destinatario
      $mail->AddAddress($address, "Miguel Angel");

      $_POST['tipo']=$tipo;
      $pdf=null;
      $apiUrl = 'cestero.cestanavidad_default';
      $postData = $_POST;
      $client = new Client();

      try {
        $response = $client->post($apiUrl, [
          'form_params' => $postData
        ]);
  
        $tempPdfFile = tempnam(sys_get_temp_dir(), 'pdf_');
        file_put_contents($tempPdfFile, $response->getBody());
  
        $mail->AddAttachment($tempPdfFile);

      } catch (Exception $e) {
          echo 'Error: ' . $e->getMessage();
      }


      // enviar
      $resul = $mail->Send();
      if(!$resul) {
        echo "Error" . $mail->ErrorInfo;
      } else {
        echo "Enviado";
      }
    }else{
      echo "NO TE HA TOCADO";
    }
      
    
    
?>