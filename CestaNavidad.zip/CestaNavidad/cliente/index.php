<?php
require 'vendor/autoload.php';

echo "
    <h1>Ojala Me Tocara</h1>
    <form action='prueba.php' method='POST'>
        <label for='nombreInput'>Nombre:</label>
        <input type='text' name='nombreInput'>
        <input type='submit' value='OJALA'>
    </form>
";

?>