<?php 
    require 'vendor/autoload.php';
    use GuzzleHttp\Client;

    // Instancia Guzzle
    $client = new Client();
    
    // URL de la API que queremos consultar
    $apiUrl = 'correo.cestanavidad_default';
    $postData = $_POST;
    try {
        $response = $client->post($apiUrl, [
            'form_params' => $postData
        ]);
    
        echo ($response->getBody());
    } catch (Exception $e) {
        // Manejo de errores en caso de que la solicitud falle
        echo 'Error: ' . $e->getMessage();
    }
?>