CREATE DATABASE IF NOT EXISTS nombreDB;

USE nombreDB;

CREATE TABLE IF NOT EXISTS cesta (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(40) NOT NULL,
    email VARCHAR(40) NOT NULL,
    tipo VARCHAR(40) NOT NULL
);

INSERT INTO cesta (nombre, email, tipo) VALUES
    ('Miguel', 'migueltortg@gmail.com','CON'),
    ('Diego', 'mtorort0502@g.educaand.es','CON'),
    ('Pedro', 'migueltortg@gmail.com','SIN');