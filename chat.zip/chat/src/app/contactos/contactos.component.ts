import { Component, Input, OnInit } from '@angular/core';
import { ContactoComponent } from '../contacto/contacto.component';
import { ContactosService } from '../servicios/contactos.service';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { MensajesService } from '../servicios/mensajes.service';

@Component({
  selector: 'app-contactos',
  standalone: true,
  imports: [ContactoComponent, HttpClientModule, CommonModule, RouterLink],
  providers: [ContactosService, MensajesService],
  templateUrl: './contactos.component.html',
  styleUrl: './contactos.component.css'
})
export class ContactosComponent implements OnInit{
  // @Input() usuario: string;
  // constructor() {
  //   this.usuario = "";
  // }

  @Input() usuario: string;
  contactos:any;
  conversacion:any;

  constructor(public contactoService: ContactosService, public mensajesService: MensajesService, private route: Router) {
    this.usuario="";
    this.contactos=[];
    this.conversacion=[];
  }

  ngOnInit(): void {
      this.contactoService.getContactos(this.usuario).subscribe(data => {
        this.contactos = data;
        console.log(this.contactos);
      });
  }

  getMensajesDeContacto() {
    this.mensajesService.getConversacionPorEmisorYReceptor(3, 2).subscribe(data => {
      this.conversacion = data;
      return (this.conversacion);
    });
  }

  onContactoSeleccionado(contacto_id: any) {
    // Handle contact selection, you can update another component here
    console.log('ID CONTACTO:', contacto_id);
  }
}
