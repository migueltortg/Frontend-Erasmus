import { Component, Input } from '@angular/core';
import { MensajesService } from '../servicios/mensajes.service';
import { MensajeComponent } from '../mensaje/mensaje.component';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-mensajes',
  standalone: true,
  imports: [MensajeComponent, HttpClientModule, CommonModule],
  providers: [MensajesService],
  templateUrl: './mensajes.component.html',
  styleUrl: './mensajes.component.css'
})

export class MensajesComponent {
  @Input() usuario: string;
  mensajes:any;
  objMensajes:any;
  mensajesTexto:any;

  constructor(public mensajesService: MensajesService) {
    this.usuario="";
    this.objMensajes=[];
    this.mensajesTexto=[];
  }

  ngOnInit(): void {
      this.mensajesService.getConversacionPorEmisorYReceptor(3, 2).subscribe(data => {
        this.mensajesTexto=data;
      });
  }
}
