import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { Router } from '@angular/router';
import { ContactosService } from '../servicios/contactos.service'; 
import { HttpClientModule } from '@angular/common/http';


@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, RouterLink, FormsModule,HttpClientModule],
  providers: [ContactosService],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  ruta:string;

  constructor(private route: Router,private contactosService: ContactosService) {
    this.ruta = "";
  }

  iniciarSesion() {
    //this.route.navigate(['/chat', this.ruta]);
    // this.router.navigateByUrl(`/chat/${this.ruta}`);
    console.log(this.ruta);
    this.contactosService.getIdContacto(this.ruta).subscribe((data: any) => {
      console.log(data);
    });
  }
}
