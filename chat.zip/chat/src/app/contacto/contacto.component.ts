import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-contacto',
  standalone: true,
  imports: [],
  templateUrl: './contacto.component.html',
  styleUrl: './contacto.component.css'
})
export class ContactoComponent {
  @Input() contacto:any;
  @Output() contactSelected = new EventEmitter<any>();

  constructor() {
    this.contacto="";
  }

  seleccionarContacto(contacto:string) {
    this.contactSelected.emit(contacto);
  }
}
