import { Component } from '@angular/core';
import { MensajesComponent } from '../mensajes/mensajes.component';

@Component({
  selector: 'app-conversacion',
  standalone: true,
  imports: [MensajesComponent],
  templateUrl: './conversacion.component.html',
  styleUrl: './conversacion.component.css'
})
export class ConversacionComponent {

}
