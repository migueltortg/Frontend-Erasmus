import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ContactosComponent } from '../contactos/contactos.component';
import { ConversacionComponent } from '../conversacion/conversacion.component';
import { HttpClient } from '@angular/common/http';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-chat',
  standalone: true,
  imports: [ContactosComponent, ConversacionComponent, FormsModule],
  templateUrl: './chat.component.html',
  styleUrl: './chat.component.css'
})
export class ChatComponent {
  usuario:string = "por defecto"

constructor(private route: ActivatedRoute, private http: HttpClient) {
  this.usuario = route.snapshot.params['id'];
}

ngOnInit() {
  this.route.params.subscribe(params => {
    this.usuario = params['id'];
  })
}

miTexto: string="";
enviarMensaje(): void {
  const emisor = { id: 2 };
  const receptor = { id: 3 };
  const texto = this.miTexto;
  
  const fechaHoraActual: string = new Date().toISOString();
  
  const formattedDate: string = this.formatDate(fechaHoraActual);

  
  const mensaje = {
    emisor: emisor,
    receptor: receptor,
    fecha_hora: formattedDate,
    texto: texto
  };
  console.log(mensaje);

  this.http.post('http://localhost:8085/api/mensajeNuevo', mensaje)
    .subscribe(
      res => {
        console.log('Enviado el mensaje:', texto);
      },
      err => {
        console.log('Error al enviar el mensaje:', err);
      }
    );
  
}

formatDate(dateString: string): string {
  const date = new Date(dateString);
  
  const year = date.getFullYear();
  const month = this.padZero(date.getMonth() + 1);
  const day = this.padZero(date.getDate());
  const hours = this.padZero(date.getHours());
  const minutes = this.padZero(date.getMinutes());
  const seconds = this.padZero(date.getSeconds());

  return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

padZero(num: number): string {
  return num < 10 ? '0' + num : num.toString();
}

}
