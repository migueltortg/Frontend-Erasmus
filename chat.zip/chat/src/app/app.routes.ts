import { Routes } from '@angular/router';
import { ChatComponent } from './chat/chat.component';
import { LoginComponent } from './login/login.component';

export const routes: Routes = [
    { path: "", component: LoginComponent, pathMatch: "full" },
    // { path: "chat", component: ChatComponent, pathMatch: "full" },
    { path: "chat/:id", component: ChatComponent, pathMatch: "full" },
];
