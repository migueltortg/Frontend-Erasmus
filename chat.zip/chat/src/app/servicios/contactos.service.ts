import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ContactosService {

  constructor(private http: HttpClient) {
    // // Estático
    // this.http.get('http://localhost/chat_pedro_api/contactos.php').subscribe(data => {
    //   console.log(data);
    // });
    // Server SPRINGBOOT
    this.http.get('http://localhost:808/api/contactos').subscribe(data => {
      console.log(data);
    });
  }

  getContactos(nick:string): Observable<any>{
    // // Estático
    // return this.http.get('http://localhost/chat_pedro_api/contactos.php?'+nick);
    // Server SPRINGBOOT
    return this.http.get('http://localhost:8085/api/contactos?');
  }

  getIdContacto(nick: string): Observable<any> {
    const params = new HttpParams().set('nick', nick); 
    return this.http.get('http://localhost:8085/api/contactoExiste', { params });
  }


}
