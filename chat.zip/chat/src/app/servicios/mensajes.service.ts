import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MensajesService {

  constructor(private http: HttpClient) {
    this.http.get('http://localhost:8081/api/mensajes/emisor/3/receptor/2').subscribe(data => {
      console.log(data);
    });
  }

  getMensajes(nick:string): Observable<any> {
    return this.http.get('http://localhost:8081/api/mensajes');
  }

  getConversacionPorEmisorYReceptor(emisor:number, receptor:number): Observable<any> {
    return this.http.get('http://localhost:8081/api/mensajes/emisor/'+emisor+'/receptor/'+receptor);
  }

}
