import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-mensaje',
  standalone: true,
  imports: [],
  templateUrl: './mensaje.component.html',
  styleUrl: './mensaje.component.css'
})
export class MensajeComponent {
  constructor() {
    this.mensaje="TEXTO GENERADO AUTOMÁTICAMENTE";
  }

  @Input() mensaje: string;
}
