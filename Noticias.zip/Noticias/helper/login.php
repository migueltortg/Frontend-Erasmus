<?php
    class login{
        public static function logIn($rol){
            login::inicioSesion();
            login::guardaSesion("role",$rol);
        }

        public static function inicioSesion(){
            if(session_status() == PHP_SESSION_NONE){
                session_start();
            }
        }

        public static function guardaSesion($clave,$valor){
            $_SESSION[$clave]=$valor;
        }

        public static function pedirValorSession($clave){
            if(empty($clave)){
                return "";
            }else{
                return $_SESSION[$clave];
            }
        }

        public static function estaLogueado(){
            return isset($_SESSION['user']);
        }

        public static function destruirSession(){
            session_destroy();
        }
    }
?>