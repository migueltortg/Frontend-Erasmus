<?php
    spl_autoload_register('autocargar');

    function autocargar($clase){
        $entities=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/entities/".$clase.'.php';
        $repository=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/repository/".$clase.'.php';
        $database=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/database/".$clase.'.php';
        $helper=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/helper/".$clase.'.php';
        $interface=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/interface/".$clase.'.php';
        $funciones=$_SERVER['DOCUMENT_ROOT']."/NOTICIAS/funciones/".$clase.'.php';


        if(file_exists($entities)){
            require_once $entities;
        }else if(file_exists($funciones)){
            require_once $funciones;
        }else if(file_exists($interface)){
            require_once $interface;
        }else if(file_exists($helper)){
            require_once $helper;
        }else if(file_exists($repository)){
            require_once $repository;
        }else if(file_exists($database)){
            require_once $database;
        }else{
            var_dump($repository);
        }
    };
?>