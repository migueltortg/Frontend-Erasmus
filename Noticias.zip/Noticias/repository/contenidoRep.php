<?php 
    class contenidoRep{

        public static function crearContenido($idContenido,$tipo,$url,$formato,$duracion){
            $contenido=new Contenido($idContenido,$tipo,$url,$formato,$duracion);
            return $contenido;
        }

        public static function arrayContenidos($array){
            $contenidos=array();
            foreach($array as $contenido){
                array_push($contenidos,contenidoRep::crearContenido($contenido->idContenido,$contenido->tipo,$contenido->url,$contenido->formato,
                $contenido->duracion));
            }
            return $contenidos;
        }

    }
?>