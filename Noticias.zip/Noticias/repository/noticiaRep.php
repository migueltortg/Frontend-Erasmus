<?php 
    class noticiaRep{

        public static function crearNoticia($idNoticia,$fecha_inicio,$fecha_fin,$titulo,$prioridad,$perfil,$duracion,$idContenido){
            $noticia=new Noticia($idNoticia,$fecha_inicio,$fecha_fin,$titulo,$prioridad,$perfil,$duracion,$idContenido);
            return $noticia;
        }

        public static function arrayNoticias($array){
            $noticias=array();
            foreach($array as $noticia){
                array_push($noticias,noticiaRep::crearNoticia($noticia->idNoticia,$noticia->fecha_inicio,$noticia->fecha_fin,$noticia->titulo,$noticia->prioridad,
                $noticia->perfil,$noticia->duracion,$noticia->idContenido));
            }
            return $noticias;
        }

        public static function cargarNoticias($conexion){
            $noticias=databaseRep::selectUniversal($conexion,"Noticia");

            foreach($noticias as $noticia){

                $todos = "";
                $profesores = "";
                $alumnos = "";
        
                switch (strtoupper($noticia->get_perfil())) {
                    case "TODOS":
                        $todos = "selected";
                        break;
                    case "PROFESORES":
                        $profesores = "selected";
                        break;
                    case "ALUMNOS":
                        $alumnos = "selected";
                        break;
                }


                echo "
                <tr id='".$noticia->get_idNoticia()."'>
                    <td>".$noticia->get_idNoticia()."</td>
                    <td>
                        <input type='datetime-local' class='fechaInicio' name='fechaInicio' value='".$noticia->get_fechaInicio()."' required>
                    </td>
                    <td>
                        <input type='datetime-local' class='fechaFin' name='fechaFin' value='".$noticia->get_fechaFin()."' required>
                    </td>
                    <td>
                        <input type='text' class='titulo' name='fechaIntituloicio' value='".$noticia->get_titulo()."' required>
                    </td>
                    <td>
                        <input type='number' class='prioridad' name='prioridad' value=".$noticia->get_prioridad()." min=1>
                    </td>
                    <td>
                        <select>
                            <option value='Alumnos' ".$alumnos.">ALUMNOS</option>
                            <option value='Profesores' ".$profesores.">PROFESORES</option>
                            <option value='Todos' ".$todos.">TODOS</option>
                        </select>
                    </td>
                    <td>
                        <input type='number' class='duracion' name='duracion' value=".$noticia->get_duracion()." min=1>
                    </td>
                    <td>
                        <button class='editarNoticia'>Editar</button>
                        <button class='borrarNoticia'>Eliminar</button>
                    </td>
                </tr>
                ";
            }
        }

    }
?>