<?php 
    class databaseRep{
        public static function selectUniversal($conexion,$tabla){
            
            $resultado = $conexion->query('SELECT * FROM '.$tabla.";", MYSQLI_USE_RESULT);
            $objetos=array();
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                array_push($objetos,$registro);
            }  
    
            switch ($tabla) {
                case "Noticia":
                    return noticiaRep::arrayNoticias($objetos);
                    break;
                case "Contenido":
                    return contenidoRep::arrayContenidos($objetos);
                    break;
                default:
                    return $objetos;
                    break;
            }
        }

        public static function contenidoID($conexion,$idContenido){
            $resultado = $conexion->query('SELECT * FROM Contenido where idContenido="'.$idContenido.'";', MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return contenidoRep::crearContenido($registro->idContenido,$registro->tipo,$registro->url,$registro->formato,$registro->duracion);
            }  
        }

        public static function añadirContenido($conexion,$contenido){
            $preparedConexion=$conexion->prepare("INSERT INTO CONTENIDO(tipo,url,formato,duracion) VALUES (:tipo,:url,:formato,:duracion);");
    
            $tipo=$contenido->get_tipo();
            $url=$contenido->get_url();
            $formato=$contenido->get_formato();
            $duracion=$contenido->get_duracion();

    
            $preparedConexion->bindParam(':tipo',$tipo);
            $preparedConexion->bindParam(':url',$url);
            $preparedConexion->bindParam(':formato',$formato);
            $preparedConexion->bindParam(':duracion',$duracion);
    
            $preparedConexion->execute();
        }

        public static function añadirNoticia($conexion,$noticia){
            $preparedConexion=$conexion->prepare("INSERT INTO NOTICIA(fecha_inicio,fecha_fin,titulo,prioridad,perfil,duracion,idContenido)
             VALUES (:fecha_inicio,:fecha_fin,:titulo,:prioridad,:perfil,:duracion,:idContenido);");
    
            $fecha_inicio=$noticia->get_fechaInicio();
            $fecha_fin=$noticia->get_fechaFin();
            $titulo=$noticia->get_titulo();
            $prioridad=$noticia->get_prioridad();
            $perfil=$noticia->get_perfil();
            $duracion=$noticia->get_duracion();
            $idContenido=$noticia->get_idContenido();

    
            $preparedConexion->bindParam(':fecha_inicio',$fecha_inicio);
            $preparedConexion->bindParam(':fecha_fin',$fecha_fin);
            $preparedConexion->bindParam(':titulo',$titulo);
            $preparedConexion->bindParam(':prioridad',$prioridad);
            $preparedConexion->bindParam(':perfil',$perfil);
            $preparedConexion->bindParam(':duracion',$duracion);
            $preparedConexion->bindParam(':idContenido',$idContenido);
    
            $preparedConexion->execute();
        }

        public static function idUltContenido($conexion,$contenido){
            $resultado = $conexion->query('SELECT * FROM Contenido where tipo="'.strtoupper($contenido->get_tipo()).'" AND url="'.$contenido->get_url().'" order by
            idContenido desc limit 1;', MYSQLI_USE_RESULT);
            
            while ($registro = $resultado->fetch(PDO::FETCH_OBJ)) {
                return $registro->idContenido;
            }  
        }

        public static function borrarNoticia($conexion,$idNoticia){
            $preparedConexion=$conexion->prepare('DELETE FROM Noticia WHERE idNoticia=:idNoticia;');
    
            $preparedConexion->bindParam(':idNoticia',$idNoticia);
            
            $preparedConexion->execute();
        }

        public static function borrarContenido($conexion){
            $preparedConexion=$conexion->prepare('DELETE FROM Contenido WHERE idContenido NOT IN (SELECT idContenido FROM NOTICIA);');
            
            $preparedConexion->execute();
        }

        public static function editarNoticia($conexion,$noticia){
            $preparedConexion=$conexion->prepare('UPDATE NOTICIA SET fecha_inicio=:fecha_inicio,fecha_fin=:fecha_fin,titulo=:titulo,prioridad=:prioridad, 
            perfil=:perfil,duracion=:duracion WHERE idNoticia=:idNoticia;');
    
            $idNoticia=$noticia->get_idNoticia();
            $fecha_inicio=$noticia->get_fechaInicio();
            $fecha_fin=$noticia->get_fechaFin();
            $titulo=$noticia->get_titulo();
            $prioridad=$noticia->get_prioridad();
            $perfil=strtoupper($noticia->get_perfil());
            $duracion=$noticia->get_duracion();
    
            $preparedConexion->bindParam(':idNoticia',$idNoticia);
            $preparedConexion->bindParam(':fecha_inicio',$fecha_inicio);
            $preparedConexion->bindParam(':fecha_fin',$fecha_fin);
            $preparedConexion->bindParam(':titulo',$titulo);
            $preparedConexion->bindParam(':prioridad',$prioridad);
            $preparedConexion->bindParam(':perfil',$perfil);
            $preparedConexion->bindParam(':duracion',$duracion);
            
            $preparedConexion->execute();
        }

        public static function editarContenido($conexion,$noticia){
            $preparedConexion=$conexion->prepare('UPDATE Contenido SET duracion=:duracion WHERE idContenido IN (SELECT idContenido FROM NOTICIA WHERE
            idNoticia=:idNoticia);');
    
            $duracion=$noticia->get_duracion();
            $id=$noticia->get_idNoticia();

            $preparedConexion->bindParam(':duracion',$duracion);
            $preparedConexion->bindParam(':idNoticia',$id);

            
            $preparedConexion->execute();
        }
    }
?>