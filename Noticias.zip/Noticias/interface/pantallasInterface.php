<?php
    class pantallasInterface{
        public static function cargarDiv(){
            echo "
                <div id='contenido'>
                </div>
                <script src='js/carrusel.js'></script>
            ";
        }
    }
?>