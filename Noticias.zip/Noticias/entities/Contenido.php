<?php 
    class Contenido implements JsonSerializable{
        // Propiedades
        private $idContenido;
        private $tipo;
        private $url;
        private $formato;
        private $duracion;

        //Constructor
        public function __construct($idContenido,$tipo,$url,$formato,$duracion) {
            $this->idContenido = $idContenido;
            $this->tipo = $tipo;
            $this->url = $url;
            $this->formato = $formato;
            $this->duracion = $duracion;
        }

        // Getters y Setters
        public function get_idContenido(){
            return $this->idContenido;
        }

        public function get_tipo(){
            return $this->tipo;
        }

        public function get_url(){
            return $this->url;
        }

        public function get_formato(){
            return $this->formato;
        }
        
        public function get_duracion(){
            return $this->duracion;
        }

        public function set_tipo($tipo) {
            $this->tipo = $tipo;
        }

        public function set_url($url){
            $this->url = $url;
        }

        public function set_formato($formato) {
            $this->formato = $formato;
        }

        public function set_duracion($duracion) {
            $this->duracion = $duracion;
        }


        //Para hacer serializable
        public function jsonSerialize(){
            $vars = get_object_vars($this);
            return $vars;
        }
    }
?>