<?php 
    class Noticia implements JsonSerializable{
        // Propiedades
        private $idNoticia;
        private $fecha_inicio;
        private $fecha_fin;
        private $titulo;
        private $prioridad;
        private $perfil;
        private $duracion;
        private $idContenido;

        //Constructor
        public function __construct($idNoticia,$fecha_inicio,$fecha_fin,$titulo,$prioridad,$perfil,$duracion,$idContenido) {
            $this->idNoticia = $idNoticia;
            $this->fecha_inicio = $fecha_inicio;
            $this->fecha_fin = $fecha_fin;
            $this->titulo = $titulo;
            $this->prioridad = $prioridad;
            $this->perfil = $perfil;
            $this->duracion = $duracion;
            $this->idContenido = $idContenido;
        }

        // Getters y Setters

        public function get_idNoticia() { 
            return $this->idNoticia; 
        }

        public function get_fechaInicio(){
            return $this->fecha_inicio;
        }

        public function get_fechaFin(){
            return $this->fecha_fin;
        }

        public function get_titulo(){
            return $this->titulo;
        }

        public function get_prioridad(){
            return $this->prioridad;
        }

        public function get_perfil(){
            return $this->perfil;
        }

        public function get_duracion(){
            return $this->duracion;
        }

        public function get_idContenido(){
            return $this->idContenido;
        }

        public function set_fechaInicio($fecha_inicio) {
            $this->fecha_inicio = $fecha_inicio;
        }

        public function set_fechaFin($fecha_fin){
            $this->fecha_fin = $fecha_fin;
        }

        public function set_titulo($titulo) {
            $this->titulo = $titulo;
        }

        public function set_prioridad($prioridad) {
            $this->prioridad = $prioridad;
        }

        public function set_perfil($perfil) {
            $this->perfil = $perfil;
        }

        public function set_duracion($duracion) {
            $this->duracion = $duracion;
        }

        public function set_idContenido($id_contenido) {
            $this->id_contenido = $id_contenido;
        }

        //Para hacer serializable
        public function jsonSerialize(){
            $vars = get_object_vars($this);
            return $vars;
        }
    }
?>