<?php 
    require_once "../helper/autocargador.php";

    login::inicioSesion();

    if(isset($_SESSION['carrusel']) &&  $_SESSION['carrusel']!=null){//SI EXISTE PASAR SIGUIENTE
        //DEVOLVER CONTENIDO Y ELIMINAR SU NOTICIA $_SESSION['carrusel']
        echo json_encode(funcionesCarrusel::devolverContenido());
    }else{
        funcionesCarrusel::cargarCarrusel($_SESSION['role']);
        echo json_encode(funcionesCarrusel::devolverContenido());
    }

?>