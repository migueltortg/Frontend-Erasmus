<?php 
    require_once "../helper/autocargador.php";

    $datos_json = file_get_contents('php://input');//Se recibe la informacion de la api con esto
    $prueba = json_decode($datos_json, true);
    
    $conexion=DB::getConexion();

    databaseRep::borrarNoticia($conexion,$prueba['idNoticia']);
    databaseRep::borrarContenido($conexion);
?>