<?php 
    require_once "../helper/autocargador.php";

    $datos_json = file_get_contents('php://input');//Se recibe la informacion de la api con esto
    $prueba = json_decode($datos_json, true);
    
    $conexion=DB::getConexion();


    $noticia=noticiaRep::crearNoticia($prueba['idNoticia'],$prueba['fecha_inicio'],
    $prueba['fecha_fin'],$prueba['titulo'],$prueba['prioridad'],$prueba['perfil'],$prueba['duracion'],"");

    databaseRep::editarNoticia($conexion,$noticia);
    databaseRep::editarContenido($conexion,$noticia);
?>