<?php 
    require_once "../helper/autocargador.php";
    
    $conexion=DB::getConexion();

    switch(strtoupper($_POST['tipo'])){
        case 'WEB':
            $contenido=contenidoRep::crearContenido("",$_POST['tipo'],$_POST['textArea'],"",$_POST['duracion']);
            break;
        case 'IMAGEN':
            $ruta="../imgNoticias/".basename($_FILES['file']['name']);
            move_uploaded_file($_FILES['file']['tmp_name'], $ruta);
            $ruta="imgNoticias/".basename($_FILES['file']['name']);
            $contenido=contenidoRep::crearContenido("",$_POST['tipo'],$ruta,"",$_POST['duracion']);
            break;
        case 'VIDEO':
            $ruta="../videoNoticias/".basename($_FILES['file']['name']);
            move_uploaded_file($_FILES['file']['tmp_name'], $ruta);
            $ruta="videoNoticias/".basename($_FILES['file']['name']);
            $contenido=contenidoRep::crearContenido("",$_POST['tipo'],$ruta,$_POST['formato'],$_POST['duracion']);
            break;
    }
    databaseRep::añadirContenido($conexion,$contenido);
    echo databaseRep::idUltContenido($conexion,$contenido); 
?>