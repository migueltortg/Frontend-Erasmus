window.addEventListener("load",function(){
    next();
});

function next() {
    fetch('api/next.php')
        .then(response => response.json())
        .then(data => {
            console.log(data);
            generarContenido(data);
            setTimeout(() => {
                next();
            }, (data.duracion)*1000);
        });
}

function generarContenido(data){
    
    switch(data.tipo){
        case "WEB":
            document.getElementById("contenido").innerHTML=data.url;
            break;
        case "IMAGEN":
            while (document.getElementById("contenido").firstChild) {
                document.getElementById("contenido").removeChild(document.getElementById("contenido").firstChild);
            }
            var imagen=document.createElement("img");
            imagen.setAttribute("src",data.url);
            imagen.setAttribute("width","100%");
            imagen.setAttribute("height","100%");
            document.getElementById("contenido").appendChild(imagen);
            break;
        case "VIDEO":
            while (document.getElementById("contenido").firstChild) {
                document.getElementById("contenido").removeChild(document.getElementById("contenido").firstChild);
            }
            var video=document.createElement("video");
            video.setAttribute("width","100%");
            video.setAttribute("height","100%");
            video.setAttribute("src",data.url);
            var formato="video/mp4";
            video.setAttribute("type",formato);

            document.getElementById("contenido").appendChild(video);
            
            video.addEventListener("ended", function() {
                video.currentTime = 0;
                video.muted=true;
                video.play();
            });
            video.muted=true;
            video.play();
            

            break;
    }
}
