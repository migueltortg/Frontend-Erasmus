window.addEventListener("load",function(){
    var btnBorrar=this.document.getElementsByClassName("borrarNoticia");
    var btnEditar=this.document.getElementsByClassName("editarNoticia");
    var tipoContenido=this.document.getElementById("tipoContenido");
    var submit=this.document.getElementById("crearNoticia");
    submit.addEventListener("click",crearContenido);

    tipoContenido.addEventListener("change",tipoContenido_crear);
    
    for(var i=0;i<btnEditar.length;i++){
        btnBorrar[i].addEventListener("click",borrarNoticia);
        btnEditar[i].addEventListener("click",editarNoticia);
    }
})

function crearContenido(ev){
    ev.preventDefault();
    var relleno=true;    
    var mayor0=true;  
    var fechasValida=true;  

    for(var i=3;i<this.parentNode.childNodes.length-12;i=i+4){
        console.log(this.parentNode.childNodes[i].type);
        if(this.parentNode.childNodes[i].value==""){
            this.parentNode.childNodes[i].style.border="3px solid red";
            relleno=false;
        }else{
            this.parentNode.childNodes[i].style.border="3px solid green";
        }
        
        if(this.parentNode.childNodes[i].type=="number"){
            if(this.parentNode.childNodes[i].value<1){
                this.parentNode.childNodes[i].style.border="3px solid red";
                mayor0=false;
            }else{
                this.parentNode.childNodes[i].style.border="3px solid green";
            }
        }
    }
    var fechaInicio=new Date(this.parentNode.childNodes[7].value);
    var fechaFin=new Date(this.parentNode.childNodes[11].value);

    if((fechaFin-fechaInicio)<0){
        this.parentNode.childNodes[11].style.border="3px solid red";
        this.parentNode.childNodes[7].style.border="3px solid red";
        fechasValida=false;
    }else{
        this.parentNode.childNodes[11].style.border="3px solid green";
        this.parentNode.childNodes[7].style.border="3px solid green";
    }
    
    var tipo=this.parentNode.childNodes[27].value;
    var duracion=this.parentNode.childNodes[15].value;
    
    if(relleno && mayor0 && fechasValida){
        switch(tipo){
            case "WEB":
                var textArea=this.parentNode.childNodes[29].childNodes[3].value;
            
                var form=new FormData();
    
                form.append("textArea",textArea);
                form.append("duracion",duracion);
                form.append("tipo",tipo);
    
                fetch('api/crearContenido.php', {
                    method: 'POST',
                    body: form
                })
                .then(response => response.text())
                .then(data => {
                    crearNoticia(this,data);
                });
                
                break;
            case "IMAGEN":
                //PASAR IMG
                var img=this.parentNode.childNodes[29].childNodes[1];
                
                var form=new FormData();
    
                form.append("file",img.files[0]);
                form.append("duracion",duracion);
                form.append("tipo",tipo);
    
                fetch('api/crearContenido.php', {
                    method: 'POST',
                    body: form
                })
                .then(response => response.text())
                .then(data => {
                    crearNoticia(this,data);
                });
    
                break;
            case "VIDEO":
                //PASAR VIDEO
                var formato=this.parentNode.childNodes[29].childNodes[1].value;
                var video=this.parentNode.childNodes[29].childNodes[3];
    
                var form=new FormData();
    
                form.append("tipo",tipo);
                form.append("formato",formato);
                form.append("duracion",duracion);
                form.append("file",video.files[0]);
    
                fetch('api/crearContenido.php', {
                    method: 'POST',
                    body: form
                })
                .then(response => response.text())
                .then(data => {
                    crearNoticia(this,data);
                });
                break;
        }
    }else if(!relleno){
        alert("Tienes que rellenar todos los campos.");
    }else if(!mayor0){
        alert("La duración y prioridad han de ser mayor de 0.");
    }else if(!fechasValida){
        alert("La fecha de fin no puede ser anterior a la de comienzo.");
    }
}

function crearNoticia(boton,id){
    var titulo=boton.parentNode.childNodes[3].value;
    var fecha_inicio=boton.parentNode.childNodes[7].value;
    var fecha_fin=boton.parentNode.childNodes[11].value;
    var duracion=boton.parentNode.childNodes[15].value;
    var prioridad=boton.parentNode.childNodes[19].value;
    var perfil=boton.parentNode.childNodes[23].value;

    fetch('api/crearNoticia.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({"fecha_inicio":fecha_inicio,"fecha_fin":fecha_fin,"titulo":titulo,"prioridad":prioridad,"perfil":perfil,"duracion":duracion,"idContenido":id})
      })
      .then(response => response.text())
      .then(data => {
        location.reload();
    });
}

function tipoContenido_crear(){
    var container=this.parentNode.childNodes[29];
    
    while (container.firstChild) {
        container.removeChild(container.firstChild);
    }

    switch(this.value){
        case "WEB":
            var label=document.createElement("label");
            var input=document.createElement("textarea");

            label.setAttribute("for","contenidoWeb");
            label.innerHTML="Contenido Web:";

            container.appendChild(label);
            container.appendChild(input);
            
            break;
        case "IMAGEN":
            var label=document.createElement("label");
            var input=document.createElement("input");

            label.setAttribute("name","selecionarArchivo");
            label.innerHTML="Seleccionar Archivo:";

            input.setAttribute("type","file");
            input.setAttribute("id","inputArchivo");
            input.setAttribute("accept","image/png, image/jpeg");

            container.appendChild(label);
            container.appendChild(input);

            break;
        case "VIDEO":
            var label=document.createElement("label");
            var select=document.createElement("select");
            var input=document.createElement("input");

            label.setAttribute("name","formatoVideo");
            label.innerHTML="Formato:";
            select.setAttribute("id","formatoVideo");
            select.setAttribute("name","formatoVideo");
        
            var mp4=document.createElement("option");
            var avi=document.createElement("option");

            mp4.setAttribute("value","MP4");
            mp4.innerHTML="MP4";
            avi.setAttribute("value","AVI");
            avi.innerHTML="AVI";

            var labelArchivo=document.createElement("label");
            labelArchivo.setAttribute("name","selecionarArchivo");
            labelArchivo.innerHTML="Seleccionar Archivo:";
            
            input.setAttribute("type","file");
            input.setAttribute("id","inputArchivo");
            input.setAttribute("accept",".avi, .mp4");

            container.appendChild(label);
            select.appendChild(mp4);
            select.appendChild(avi);
            container.appendChild(select);
            container.appendChild(labelArchivo);
            container.appendChild(input);
            break;
    }
}

function borrarNoticia(){
    //API BORRAR NOTICIAS
    var idNoticia=this.parentNode.parentNode.id;
    
    fetch('api/borrarNoticia.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
      },
      body: JSON.stringify({"idNoticia":idNoticia})
      })
      .then(response => response.text())
      .then(data => {
        location.reload();
    });
}

function editarNoticia(){
    var idNoticia=this.parentNode.parentNode.id;
    var fecha_inicio=this.parentNode.parentNode.childNodes[3].childNodes[1].value;
    var fecha_fin=this.parentNode.parentNode.childNodes[5].childNodes[1].value;
    var titulo=this.parentNode.parentNode.childNodes[7].childNodes[1].value;
    var prioridad=this.parentNode.parentNode.childNodes[9].childNodes[1].value;
    var perfil=this.parentNode.parentNode.childNodes[11].childNodes[1].value;
    var duracion=this.parentNode.parentNode.childNodes[13].childNodes[1].value;

    fetch('api/editarNoticia.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({"idNoticia":idNoticia,"fecha_inicio":fecha_inicio,"fecha_fin":fecha_fin,"titulo":titulo,"prioridad":prioridad,"perfil":perfil,"duracion":duracion})
    })
    .then(response => response.text())
    .then(data => {
        location.reload();
    });
}