<head>
    <meta charset="UTF-8">
    <title>IES LAS FUENTEZUELAS</title>
    <link rel="icon" href="img/icon.jpg" type="image/x-icon">
    <link rel="stylesheet" href="css/style.css">

</head>