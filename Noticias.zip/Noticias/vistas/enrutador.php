<?php
    if (isset($_GET['vista'])) {
        if ($_GET['vista'] == "admin") {
            //Mostramos el HEAD.
            require_once 'vistas/principal.php';
            
            //Mostramos el MAIN.
            require_once "vistas/mainAdmin.php";
        }
        if($_GET['vista']=="user"){
            //Mostramos el HEAD.
            require_once 'vistas/principal.php';
            
            //Accedemos al enrutador de las pantallas
            require_once "vistas/pantallas/enrutaPantallas.php";
        }
    }
?>