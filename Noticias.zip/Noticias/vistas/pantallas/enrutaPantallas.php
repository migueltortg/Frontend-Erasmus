<?php 
    if (isset($_GET['role'])) {
        if ($_GET['role'] == "profesores") {
            //CREAS LA SESSION PROFESOR
            login::logIn("profesores");
            login::guardaSesion("carrusel",null);
        }
        if($_GET['role']=="alumnos"){
            //CREAS LA SESSION ALUMNO
            login::logIn("alumnos");
            login::guardaSesion("carrusel",null);
        }
        //ACCEDES AL PANTALLAS
        require_once "pantallas.php";
    }

?>