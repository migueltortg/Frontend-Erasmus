<?php 
    login::inicioSesion();

    pantallasInterface::cargarDiv();
?>