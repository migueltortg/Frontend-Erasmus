<div id="tablaCRUD">
    <h1>CRUD NOTICIAS</h1>
    <table border='2px'>
        <thead>
            <tr>
                <th>ID</th>
                <th>FECHA INICIO</th>
                <th>FECHA FIN</th>
                <th>TITULO</th>
                <th>PRIORIDAD</th>
                <th>PERFIL</th>
                <th>DURACIÓN</th>
                <th>ACCIONES</th>
            </tr>
        </thead>
        <tbody>
            <?php 
                $conexion=DB::getConexion();
                noticiaRep::cargarNoticias($conexion);
            ?>
        </tbody>
    </table>
</div>
<div id="crearContenido">
    <h1>Crear Noticia</h1>
    <form action="" method="POST">
        <label for="titulo">Titulo:</label>
        <input type="text" name="titulo" required>
        <label for="fechaInicio">Fecha Inicio:</label>
        <input type='datetime-local' name='fechaInicio' required>
        <label for="fechaFin">Fecha Fin:</label>
        <input type='datetime-local' name='fechaFin' required>
        <label for="duracion">Duración:</label>
        <input type='number' name='duracion' min=1 required>
        <label for="prioridad">Prioridad:</label>
        <input type='number' name='prioridad' min=1 required>
        <label for="perfil">Perfil:</label>
        <select name="perfil">
            <option value='TODOS'>TODOS</option>
            <option value='ALUMNOS'>ALUMNOS</option>
            <option value='PROFESORES'>PROFESORES</option>
        </select>
        <label for="tipoCont">Tipo Contenido:</label>
        <select id="tipoContenido">
            <option value='WEB'>WEB</option>
            <option value='IMAGEN'>IMAGEN</option>
            <option value='VIDEO'>VIDEO</option>
        </select>
        <div id="tipoContenido_container">
            <label for="contenidoWeb">Contenido Web:</label>
            <textarea></textarea>
        </div>
        <input type="submit" id="crearNoticia" value="Crear Noticia">
    </form>
</div>
<script src="js/noticiaCRUD.js"></script>