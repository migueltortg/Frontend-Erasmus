<?php
    class funcionesCarrusel{
        public static function cargarCarrusel($role){
            $conexion=DB::getConexion();

            $matrizCarrusel=databaseRep::selectUniversal($conexion,"Noticia");
            $fechaSistema=new DateTime();
            foreach($matrizCarrusel as $noticia){
                $fechaInicio=new DateTime($noticia->get_fechaInicio());
                $fechaFin=new DateTime($noticia->get_fechaFin());
                if((strtoupper($role)==strtoupper($noticia->get_perfil()) || strtoupper($noticia->get_perfil())=="TODOS") &&
                ($fechaInicio->diff($fechaSistema)->invert<=0 && $fechaFin->diff($fechaSistema)->invert>0)){
                    for($i=0;$i<$noticia->get_prioridad()-1;$i++){
                        array_push($matrizCarrusel,$noticia);
                    }
                }else{
                    unset($matrizCarrusel[array_search($noticia, $matrizCarrusel)]);
                }
            }

            $matrizCarrusel=array_values($matrizCarrusel);

            shuffle($matrizCarrusel);    

            login::guardaSesion("carrusel",$matrizCarrusel);
        }

        public static function devolverContenido(){
            $conexion=DB::getConexion();

            if(isset($_SESSION['carrusel'][0])){
                $contenido=databaseRep::contenidoID($conexion,$_SESSION['carrusel'][0]->get_idContenido());
                unset($_SESSION['carrusel'][0]);
                $_SESSION['carrusel'] = array_values($_SESSION['carrusel']);
                return $contenido;
            }else{
                return "No existen noticias";
            }
            
        }
    }
?>